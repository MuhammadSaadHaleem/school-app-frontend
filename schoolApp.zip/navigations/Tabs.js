import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import React from 'react'
import { HomeScreenMain } from '../screens/HomeScreen';
import { QuestionSolving } from '../screens/QuestionSolving';
import { Help } from '../screens/Help';
import { Settings } from '../screens/Settings';

const Tab = createBottomTabNavigator();


export const Tabs = () => {
  return (
    <Tab.Navigator>
      <Tab.Screen name="HomeScreenMain" component={HomeScreenMain} />
      <Tab.Screen name="QuestionSolving" component={QuestionSolving} />
      <Tab.Screen name="Help" component={Help} />
      <Tab.Screen name="Settings" component={Settings} />

    </Tab.Navigator>
  )
}
