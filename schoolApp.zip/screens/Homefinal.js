import React from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    TouchableOpacity,
    ImageBackground,
    FlatList,
} from "react-native";
import { useEffect, useState, useRef } from "react";
import { IconButton } from "react-native-paper";
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from "react-native-responsive-screen";

const sliderData = [
    {
        id: 1,
        image3: require("../assets/images/bgNew1.png"),
        text1: "RECOMMENDED SUBJECT FROM SYLLABUS WITH",
        text2: "Get Started",
        personImg: require("../assets/images/person.png"),
    },
    {
        id: 2,
        image3: require("../assets/images/rectangle15.png"),
        text1: "RECOMMENDED SUBJECT FROM SYLLABUS WITH",
        text2: "Get Started",
        personImg: require("../assets/images/person.png"),
    },
];

export const Homefinal = ({ navigation }) => {
    const [videoList, setVideoList] = useState([]);
    const flatListRef = useRef(null);

    useEffect(() => {
        getVideoCourse();
        // startAutoScroll();
    }, []);

    useEffect(() => {
        const intervalId = setInterval(() => {
          if (flatListRef.current) {
            flatListRef.current.scrollToOffset({
              animated: true,
              offset: 125, // Adjust this value based on the width of your items
            });
          }
        }, 3000); // Adjust the interval duration as needed
    
        return () => clearInterval(intervalId);
      }, []);

    const getVideoCourse = async () => {
        const result = sliderData.map((item) => ({
            id: item.id,
            text: item.text1,
            text2: item.text2,
            bgImg: item.image3,
            person: item.personImg,
        }));
        setVideoList(result);
    };

    React.useLayoutEffect(() => {
        navigation.setOptions({
            headerShown: false,
        });
    }, [navigation]);

    return (
        <View style={styles.container}>
            <View style={styles.firstContainer}>
                <Image
                    source={require("../assets/images/toy.png")}
                    resizeMode="cover"
                    style={styles.image9}
                />
                <Image
                    source={require("../assets/images/coin.png")}
                    resizeMode="cover"
                    style={styles.image9}
                />
            </View>

            <View style={styles.headingDiv}>

                <IconButton
                    icon="menu" // Replace with the icon name you want for the side menu
                    size={30}
                    onPress={() => {
                        navigation.navigate('ProfileEdit'); // Replace 'YourScreenName' with the actual name of the screen you want to navigate to

                    }}
                    style={styles.icon}
                />
                <Text style={styles.heading6}>
                    Hi, Wilson
                    {/* <Image
        source={require("../assets/images/wave.png")}
        resizeMode="cover"
        style={styles.miniImage}
      /> */}
                </Text>

                <Image
                    source={require("../assets/images/toy12.png")}
                    resizeMode="cover"
                />
            </View>

            <View style={styles.mainContainer}>
                <FlatList
                    data={videoList}
                    // pagingEnabled={true}
                    horizontal={true}
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={{
                        padding: 0,
                        margin: 0,
                        flexDirection: "row",
                        justifyContent: "flex-start",
                        gap: -125,
                    }}
                    style={styles.sliderStyle}
                    renderItem={({ item }) => (
                        <View style={styles.mainDiv}>
                            <ImageBackground
                                source={item.bgImg}
                                style={styles.backgroundImage}
                                imageStyle={{ borderRadius: 7 }}
                            >
                                <View style={styles.innerDiv}>
                                    <View style={styles.paraDiv}>
                                        <Text style={styles.heading8}>{item.text}</Text>
                                        <TouchableOpacity style={styles.smallDiv}>
                                            <Text style={styles.buttonInner}>{item.text2}</Text>
                                        </TouchableOpacity>
                                    </View>
                                    <Image
                                        source={item.person}
                                        resizeMode="contain"
                                        style={styles.image15}
                                    />
                                </View>
                            </ImageBackground>
                        </View>
                    )}
                />
            </View>

            <View style={styles.fourDiv}>
                <View style={styles.fourFirst}>
                    <Text style={styles.heading2}>My Courses</Text>
                    <Text style={styles.para10}>View All</Text>
                </View>

                <View style={styles.fourSecond}>
                    <TouchableOpacity onPress={()=>navigation.navigate("Help")}>
                        <ImageBackground
                            source={require("../assets/images/bg1.png")}
                            imageStyle={{ borderRadius: 14 }}
                            style={styles.fourSecondOne}
                        >
                            <Image
                                source={require("../assets/images/toy21.png")}
                                resizeMode="contain"
                                style={styles.miniImage2}
                            />

                            <Text style={styles.heading3}>BRAINY SOLVER</Text>
                        </ImageBackground>
                    </TouchableOpacity>

                    <TouchableOpacity>
                        <ImageBackground
                            source={require("../assets/images/rectangle5.png")}
                            imageStyle={{ borderRadius: 14 }}
                            style={styles.fourSecondOne}
                        >
                            <Image
                                source={require("../assets/images/toy22.png")}
                                resizeMode="contain"
                                style={styles.miniImage7}
                            />

                            <Text style={styles.heading4}>QUIZ AND MOCK TEST</Text>
                        </ImageBackground>
                    </TouchableOpacity>
                </View>

                <View style={styles.fourSecond}>
                    <TouchableOpacity>
                        <ImageBackground
                            source={require("../assets/images/rectangle6.png")}
                            imageStyle={{ borderRadius: 14 }}
                            style={styles.fourSecondOne}
                        >
                            <Image
                                source={require("../assets/images/toy23.png")}
                                resizeMode="contain"
                                style={styles.miniImage5}
                            />

                            <Text style={styles.heading4}>LEARN FROM SYLLABUS</Text>
                        </ImageBackground>
                    </TouchableOpacity>

                    <TouchableOpacity>

                        <ImageBackground
                            source={require("../assets/images/rectangle7.png")}
                            imageStyle={{ borderRadius: 14 }}
                            style={styles.fourSecondOne}
                        >
                            <Image
                                source={require("../assets/images/toy24.png")}
                                resizeMode="contain"
                                style={styles.miniImage6}
                            />

                            <Text style={styles.heading4}>LEARN FROM INTEREST</Text>
                        </ImageBackground>
                    </TouchableOpacity>
                </View>

                <View style={styles.fourSecond}>
                    <TouchableOpacity onPress={()=>navigation.navigate("BrainPage2")}>
                        <ImageBackground
                            source={require("../assets/images/bg8.png")}
                            imageStyle={{ borderRadius: 14 }}
                            style={styles.fourSecondOne}
                        >
                            <Image
                                source={require("../assets/images/toy25.png")}
                                resizeMode="contain"
                                style={styles.miniImage3}
                            />

                            <Text style={styles.heading3}>Brainy Tool 5</Text>
                        </ImageBackground>
                    </TouchableOpacity>

                    <TouchableOpacity  onPress={()=>navigation.navigate("ParentalReports")}  >
                        <ImageBackground
                            source={require("../assets/images/rectangle8.png")}
                            imageStyle={{ borderRadius: 14 }}
                            style={styles.fourSecondOne}
                        >
                            <Image
                                source={require("../assets/images/toy26.png")}
                                resizeMode="contain"
                                style={styles.miniImage4}
                            />

                            <Text style={styles.heading4}>PERFORMANCE OR PARENTAL REPORT</Text>
                        </ImageBackground>
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop: hp(7),
        alignItems: "center",
    },

    smallDiv: {
        height: "24%",
        width: "60%",
        backgroundColor: "#fff",
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 20,
    },

    heading2: {
        fontSize: 20,
        color: "#19245D",
        fontWeight: "700",
    },

    fourDiv: {
        // borderWidth: 2,
        width: "100%",
        position: "relative",
        bottom: "5%",
        paddingHorizontal: 10,
        // marginTop:"",
        marginTop: "7%",
        // marginBottom:"4%"
    },
    fourFirst: {
        // borderWidth: 2,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 8,
        paddingHorizontal: 17,
    },
    fourSecond: {
        flexDirection: "row",
        justifyContent: "center",
        gap: 9,
        width: "100%",
        height: hp(13.3),
        marginBottom: 8,
    },
    fourSecondOne: {
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        width: wp(44),
        height: hp(13),
        borderRadius: 10,
    },
    fourSecondTwo: {
        flexDirection: "column",
        alignItems: "center",
        width: wp(44),
        height: hp(13),
        justifyContent: "center",
        borderRadius: 10,
    },
    para10: {
        color: "#717171",
        fontSize: hp(2.1),
        fontWeight: "200",
    },
    heading3: {
        fontSize: 17,
        color: "#fff",
        fontWeight: "700",
        marginBottom: hp(0.2),
        marginTop: hp(1)
    },
    heading4: {
        fontSize: wp(4.8),
        color: "#fff",
        fontWeight: "700",
        marginBottom: hp(0.2),
        textAlign: "center",
    },
    headingDiv: {
        flexDirection: "row",
        marginTop: hp(0),
        justifyContent: "start",
        alignItems: "center",
        gap: 135,
    },
    heading6: {
        fontSize: hp(4.6),
        color: "#19245D",
        fontWeight: "700",
        left:25
    },
    backgroundImage: {
        flexDirection: "row",
        justifyContent: "center",
        // gap:10,
        // marginRight:-150,
        resizeMode: "contain",
        height: "96%",
        width: "100%",
        flexDirection: "row",
        // backgroundColor:"red"
    },
    innerDiv: {
        flexDirection: "row",
        alignItems: "center",
        //   borderWidth: 2,
        width: "95%",
        marginTop: 7,
        padding: 8,
        // gap:20
    },
    paraDiv: {
        //   borderWidth:2,
        width: "64%",
        justifyContent: "center",
    },
    heading8: {
        fontSize: 17,
        color: "#fff",
        fontWeight: "700",
        marginBottom: hp(2),
        textAlign: "left",
    },
    para5: {
        color: "#fff",
        marginTop: 10,
        textAlign: "left",
    },
    mainContainer: {
        flexDirection: "row",
        justifyContent: "center",
        marginTop: "4%",
        // borderWidth:2,
        height: "25%",
        marginRight: "-21%",
    },

    miniImage2: {
        // borderWidth:3,
        height: "30%",
        width: "100%",
    },
    // text:{
    //  width:"41%"

    // },
    miniImage3: {
        // borderWidth:3,
        height: "55%",
        width: "100%",
    },
    miniImage4: {
        // borderWidth:3,
        height: "43%",
        width: "100%",
    },
    miniImage5: {
        // borderWidth:3,
        height: "40%",
        width: "100%",
    },
    miniImage6: {
        // borderWidth:3,
        height: "35%",
        width: "100%",
    },
    miniImage7: {
        // borderWidth:3,
        height: "38%",
        width: "100%",
    },
    firstContainer: {
        // borderWidth:2,
        flexDirection: "row",
        alignItems: "flex-start",
        justifyContent: "space-between",
        gap: 220,
        marginTop: "2%",
    },
    image15: {
        width: "100%",
        height: "100%",
        position: "relative",
        right: "66%",
        bottom: "3%",
    },
    sliderStyle: {
        height: 200,
        // backgroundColor:"blue",
        // flexDirectio:"row",
        // justifyContent:"center"
    },

    mainDiv: {
        // borderWidth:2,
        // flexDirection:"column",
        width: "65%",
        height: "75%",
        // marginRight:-,
        // justifyContent:"center",
        // gap:-100
    },

    icon: {
        position: "absolute",
        left: 16, // Adjust the left position as needed
        top: "20%", // Adjust the top position as needed
    },

    icon: {
        position: "absolute",
        left: -25, // Adjust the left position as needed
        top: "-7%", // Adjust the top position as needed
        
    },

});