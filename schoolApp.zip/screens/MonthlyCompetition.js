import React, { useState } from 'react'
import { View, Text, StyleSheet, Image, TextInput, TouchableOpacity } from 'react-native';
import RNPickerSelect from 'react-native-picker-select';

export const MonthlyCompetition = () => {
    const [selectedSubject, setSelectedSubject] = useState(null);

    return (
        <View style={styles.container}>
            <Image
                source={require("../assets/MonthlyCompetition.png")}
                resizeMode="contain"
                style={styles.mainImage2}
            />
            <View style={styles.labelInputContainer}>
                <Text style={styles.label}>Upcoming Quiz</Text>
                <TextInput
                    style={styles.input}
                    placeholder="Upcoming Quiz"
                />
            </View>

            <View style={styles.labelInputContainer}>
                <Text style={styles.label}>Enroll Now</Text>
                <TextInput
                    style={styles.input}
                    placeholder="Enroll Now"
                />
            </View>

            <View style={styles.dropdownContainer}>
                <Text style={styles.label}>List of Topic</Text>
                <RNPickerSelect
                    onValueChange={(value) => setSelectedSubject(value)}
                    items={[
                        { label: 'Mathematics', value: 'mathematics' },
                        { label: 'Science', value: 'science' },
                    ]}
                    placeholder={{ label: 'Enroll Now', value: null }}
                    value={selectedSubject}
                    style={{
                        inputIOS: styles.dropdownInput,
                        inputAndroid: styles.dropdownInput,
                    }}
                />
            </View>

            <TouchableOpacity onPress={() => navigation.navigate("HomeScreen")}>
                <View style={styles.editProfileBox}>
                    <Text style={styles.editProfile}>SART THE QUIZ</Text>
                </View>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    input: {
        height: 40,
        borderColor: '#3C3C3C',
        borderWidth: 1,
        marginBottom: 10,
        paddingLeft: 10,
        width: '80%',
        borderRadius: 20,
    },
    labelInputContainer: {
        marginBottom: 10,
        width: '122%',
        paddingLeft: "20%",
        top: "-8%",
    },
    label: {
        fontSize: 16,
        marginBottom: 10,
        fontWeight: "bold",
        color: "#595959"
    },
    mainImage2: {
        top: "-8%"
    },
    dropdownInput: {
        height: 40,
        borderColor: '#3C3C3C',
        borderWidth: 1,
        marginBottom: 10,
        paddingLeft: 10,
        width: '80%',
        borderRadius: 30, // Add background color to avoid transparency
    },
    dropdownContainer: {
        marginBottom: 10,
        width: '122%',
        paddingLeft: "20%",
        top: "-8%",

    },

    editProfileBox: {
        // Border color for the box
        borderWidth: 1, // Border width for the box
        borderRadius: 5, // Border radius for the box
        padding: 5, // Padding for the box content // Adjust the marginTop as needed
        backgroundColor: "#19245D",
        width: 320,
        height: 50,
        borderRadius: 30,
        top: "-50%",
    },

    editProfile: {
        top: '-5%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 10,
        fontSize: 18
    },
});
