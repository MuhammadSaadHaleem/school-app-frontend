import { useNavigation } from '@react-navigation/native';
import React from 'react'
import { View, Text, Button, StyleSheet, Image, Pressable, ImageBackground, TextInput, KeyboardAvoidingView, Platform, TouchableOpacity } from 'react-native';
import Icon from 'react-native-ico-material-design';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';

export const TypeYourQuestion = () => {

    const navigation = useNavigation();
    const handleBack = () => {
        navigation.goBack()
    }
    return (
        <KeyboardAvoidingView
            style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
            }}
            behavior={Platform.OS === 'ios' ? 'padding' : null}
            keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 100}>


            <ImageBackground
                source={require("../assets/Rectangle 319.png")}
                style={styles.mainImage2}
                resizeMode='contain'
            >

                <TouchableOpacity onPress={handleBack}>
                    <IoniconsIcon name="arrow-back" size={30} color="white" style={styles.backIcon} />
                </TouchableOpacity>

                <Text style={styles.imageText}>Searching your</Text>
                <Text style={styles.imageText}>Answer & Solve Ai</Text>
            </ImageBackground>

            <View style={styles.labelInputContainer}>
                <Text style={styles.label}>Type Your Question</Text>
                <TextInput
                    style={styles.input}
                    placeholder="Predict the top Loser (for tomorrow) ..."
                />
            </View>

        </KeyboardAvoidingView>
    )
}

const styles = StyleSheet.create({
    mainImage2: {

        top: "-49%",
        height: "120%",
        width: "100%",
        justifyContent: 'center', // Center the text vertically
        alignItems: 'center',
        position: "absolute"


    },
    imageText: {
        color: 'white',
        fontSize: 30,
        fontWeight: 'bold',
        top: "18%"
    },

    labelInputContainer: {
        marginBottom: 10,
        width: '122%',
        paddingLeft: "20%",
        top: "10%",
    },
    label: {
        fontSize: 16,
        marginBottom: 10,
        fontWeight: "bold",
        color: "#595959"
    },
    input: {
        height: 40,
        marginBottom: 10,
        paddingLeft: 10,
        width: '80%',
    },

    backIcon:{
        right:"40%",
        top:"100%"
    }
})
