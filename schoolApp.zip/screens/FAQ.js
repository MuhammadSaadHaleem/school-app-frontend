import React, { useState } from 'react'
import { View, Text, StyleSheet, Image, Dimensions, TouchableOpacity, ImageBackground } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';


const FAQ = () => {


    const [accordion1Expanded, setAccordion1Expanded] = useState(false)
    const [accordion2Expanded, setAccordion2Expanded] = useState(false)
    const [accordion3Expanded, setAccordion3Expanded] = useState(false)
    const [accordion4Expanded, setAccordion4Expanded] = useState(false)

    const toggleAccordion1 = () => {
        setAccordion1Expanded(!accordion1Expanded)
    }

    const toggleAccordion2 = () => {
        setAccordion2Expanded(!accordion2Expanded)
    }

    const toggleAccordion3 = () => {
        setAccordion3Expanded(!accordion3Expanded)
    }

    const toggleAccordion4 = () => {
        setAccordion4Expanded(!accordion4Expanded)
    }


    const navigation = useNavigation();
    const handleBack = () => {
        navigation.goBack()
    }

    return (
        <View style={styles.container}>
            <LinearGradient
                colors={['#72D8FE', '#2CB4EC']}
                style={styles.cardGradient}
            />

            <View style={styles.backButton}>
                <TouchableOpacity onPress={handleBack}>
                    <IoniconsIcon name="arrow-back" size={30} color="white" style={styles.backIcon} />
                </TouchableOpacity>
            </View>

            <View style={styles.textMain}>
                <Text style={styles.mainText}>Frequently Asked Question</Text>
            </View>

            <View style={styles.mainAccordion}>

                {/* Accordion 1 */}
                <TouchableOpacity onPress={toggleAccordion1} style={styles.accordionHeader}>
                    <Text style={styles.accordionHeaderText}>Accordion 1</Text>
                    <IoniconsIcon name={accordion1Expanded ? "chevron-up" : "chevron-down"} size={24} color="black" />
                </TouchableOpacity>
                {accordion1Expanded && <View style={styles.accordionContent}>
                    <Text>Accordion 1 content goes here.</Text>
                </View>}

                {/* Accordion 2 */}

                <TouchableOpacity onPress={toggleAccordion2} style={styles.accordionHeader}>
                    <Text style={styles.accordionHeaderText}>Accordion 2</Text>
                    <IoniconsIcon name={accordion2Expanded ? "chevron-up" : "chevron-down"} size={24} color="black" />
                </TouchableOpacity>

                {accordion2Expanded && <View style={styles.accordionContent}>
                    <Text>Accordion 2 content goes here.</Text>
                </View>}


                {/* Accordion 3 */}

                <TouchableOpacity onPress={toggleAccordion3} style={styles.accordionHeader}>
                    <Text style={styles.accordionHeaderText}>Accordion 3</Text>
                    <IoniconsIcon name={accordion3Expanded ? "chevron-up" : "chevron-down"} size={24} color="black" />

                </TouchableOpacity>
                {accordion3Expanded && <View style={styles.accordionContent}>
                    <Text>Accordion 3 content goes here.</Text>
                </View>}

                {/* Accordion 4 */}
                <TouchableOpacity onPress={toggleAccordion4} style={styles.accordionHeader}>
                    <Text style={styles.accordionHeaderText}>Accordion 4</Text>
                    <IoniconsIcon name={accordion4Expanded ? "chevron-up" : "chevron-down"} size={24} color="black" />

                </TouchableOpacity>

                {accordion4Expanded && <View style={styles.accordionContent}>
                    <Text>Accordion 4 content goes here.</Text>
                </View>
                }
            </View>
        </View>
    )
}

export default FAQ

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },

    cardGradient: {
        flex: 1,
        backgroundColor: 'transparent', // Set the background to transparent so that the gradient is visible
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        borderRadius: 50,
        height: "40%",
        width: "100%",
        marginTop: "-15%",
    },
    backIcon: {
        left: -160,

    },

    mainText: {

        fontSize: 26,
        fontWeight: "bold",
        color: "white"
    },

    accordionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '95%',
        paddingVertical: 20,
        paddingHorizontal: 20,
    },
    accordionHeaderText: {
        fontSize: 18,
        fontWeight: "bold"
    },
    accordionContent: {
        width: '95%',
        padding: 20,
        // backgroundColor: '#e0e0e0',
    },

    mainAccordion: {
        
        top: 100,
    },
    textMain: {
        // borderWidth: 1,
        // borderColor: '#19245D',
        position: "absolute",
        top: "21%"
    },

    backButton:{
        position:"absolute",
        top:"11%"
    }
})