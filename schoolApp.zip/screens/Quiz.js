import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TextInput, TouchableOpacity, ImageBackground } from 'react-native';
import RNPickerSelect from 'react-native-picker-select';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';

export const Quiz = () => {
    const [selectedSubject, setSelectedSubject] = useState(null);

    const navigation = useNavigation();
    const handleBack = () => {
        navigation.goBack()
    }
    return (
        <View style={styles.container}>
            <Image
                source={require("../assets/Quiz1.png")}
                resizeMode="contain"
                style={styles.mainImage2}
            />
            
            <ImageBackground 
            source={require("../assets/Quiz1.png")}
            resizeMode="contain"
            style={styles.mainImage2}>

                
            </ImageBackground>
            {/* <TouchableOpacity onPress={handleBack}>
                    <IoniconsIcon name="arrow-back" size={30} color="#000000" style={styles.backIcon} />
                </TouchableOpacity> */}

            <View style={styles.labelInputContainer}>
                <Text style={styles.label}>Select the subject</Text>
                <TextInput
                    style={styles.input}
                    placeholder="Type Subject Name"
                />
            </View>
            <View style={styles.dropdownContainer}>
                <Text style={styles.label}>Select The Chapter</Text>
                <RNPickerSelect
                    onValueChange={(value) => setSelectedSubject(value)}
                    items={[
                        { label: 'Mathematics', value: 'mathematics' },
                        { label: 'Science', value: 'science' },
                    ]}
                    placeholder={{ label: 'Select a subject', value: null }}
                    value={selectedSubject}
                    style={{
                        inputIOS: styles.dropdownInput,
                        inputAndroid: styles.dropdownInput,
                    }}
                />
            </View>

            <TouchableOpacity onPress={() => navigation.navigate("Learning")}>
                <View style={styles.editProfileBox}>
                    <Text style={styles.editProfile}>SART THE QUIZ</Text>
                </View>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    input: {
        height: 40,
        borderColor: '#3C3C3C',
        borderWidth: 1,
        marginBottom: 10,
        paddingLeft: 10,
        width: '80%',
        borderRadius: 20,
    },
    labelInputContainer: {
        marginBottom: 10,
        width: '122%',
        paddingLeft: "20%",
        top: "-12%",
    },
    label: {
        fontSize: 16,
        marginBottom: 10,
        fontWeight: "bold",
        color: "#595959"
    },
    mainImage2: {
        top: "-12%"
    },
    dropdownInput: {
        height: 40,
        borderColor: '#3C3C3C',
        borderWidth: 2,
        marginBottom: 10,
        paddingLeft: 10,
        width: '80%',
        borderRadius: 30, // Add background color to avoid transparency
    },
    dropdownContainer: {
        marginBottom: 10,
        width: '122%',
        paddingLeft: "20%",
        top: "-11%",
    },

    editProfileBox: {
        // Border color for the box
        borderWidth: 1, // Border width for the box
        borderRadius: 5, // Border radius for the box
        padding: 5, // Padding for the box content // Adjust the marginTop as needed
        backgroundColor: "#19245D",
        width: 320,
        height: 50,
        borderRadius: 30,
        top: "-50%",
    },

    editProfile: {
        top: '-5%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 10,
        fontSize: 18
    },
    backIcon:{
        right:"40%",
        top:"-200"
    }
});

export default Quiz;
