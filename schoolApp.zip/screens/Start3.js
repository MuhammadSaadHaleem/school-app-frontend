import React, { useEffect } from 'react'
// import { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  Dimensions,
  TouchableOpacity,
  ImageBackground,
  FlatList
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { FontAwesome } from "@expo/vector-icons";
import { useNavigation } from '@react-navigation/native';


const Start3 = () => {
    const navigation= useNavigation()

    useEffect (()=>{
        const timer = setTimeout(()=>{
            navigation.navigate('SignIn')
        },5000)

        return()=>clearTimeout(timer)
    }, [navigation])

  return (
 

    <LinearGradient colors={["#72D8FE", "#2CB4EC"]} style={styles.secondDiv}>
    <Image
    source={require("../assets/images/mask6.png")}
    resizeMode="contain"
    style={styles.mainImage2}
  />  

      
    <View style={styles.container2}>
    <Text style={styles.heading2}>Student Play Game</Text>
    <Image
    source={require("../assets/images/line10.png")}
    resizeMode="cover"
    // style={styles.mainImage2}
  />  
    <Text style={styles.para}>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</Text>

    
    <Image
    source={require("../assets/images/line11.png")}
    resizeMode="cover"
    style={styles.line11}
  />  
    </View>   


    </LinearGradient>
   
      
  
     
   
    
  )
}


const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    
    },
    background: {
      width: '100%', // Set width to 100% of the screen
      alignItems: 'center',
      position:"relative",
      bottom:70,
      height:"70%"  
    
    },
    backgroundImage:{
      resizeMode: 'cover',
      height: 165,
      width: '95%',
      borderRadius:20,
      marginLeft:17
       
  
    },
    heading:{
    fontSize:26,
    color:"#FFFFFF",
    fontWeight:"900"
  
  
  
    },
    heading2:{
      fontSize:22,
      color:"#FFFFFF",
      fontWeight:"900"
    
    
    
      },
     
   
    maindiv: {
      flexDirection: 'row',
      height: 300,
      justifyContent: 'center',
      alignItems: 'center',
      // borderWidth: 2,
      width: '100%',
      marginTop: 70,
    },
    innerDiv: {
      flexDirection: 'column',
      justifyContent: 'flex-start',
      alignItems: 'flex-start',
      // borderWidth: 2,
      width: '100%',
      marginTop: 20,
      padding:10
  
    },
    smallDiv: {
      height: 37,
      width: 113,
      backgroundColor: '#19245D',
      justifyContent: 'center',
      alignItems: 'center',
      borderRadius: 5,
      marginRight:20
    },
    thirdDiv: {
      flexDirection:"row",
      justifyContent:"space-between",
      marginTop:20,
      // alignItems:"center"
    
    },
    secondDiv: {
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      // borderWidth: 2,
      borderRadius:25,
      // backgroundColor: '#AEE7FF',
      width: '100%',
      height:180
    },
    maintext: {
      fontSize: 34,
      fontWeight: 'bold',
      marginLeft: 30,
      color: '#19245D',
      marginTop: 50,
    },
    image5: {
      height: '100%',
      width: '65%',
      marginRight: 30,
    },
    title: {
      fontSize: 24,
      fontWeight: 'bold',
      marginBottom: 10,
    },
    description: {
      fontSize: 16,
      color: '#555',
      textAlign: 'center',
    },
    paraDiv:{
    marginTop:10,
    flexDirection:"column",
    width:"100%"
   
  
  
    },
    para:{
   color:"#FFFFFF",
   fontSize:17,
   fontWeight:"200",
   textAlign:"center",
   width:"90%",
   lineHeight:29,
  paddingHorizontal:10
  
  
    },
    image6:{
    position:"relative",
    left:250,
  
  
  
    },
    secondDiv: {
        flexDirection: 'column',
        // alignItems: 'c',
        justifyContent: 'flex-start',
        // borderWidth: 2,
        // backgroundColor: '#AEE7FF',
        width: '100%',
        height:"110%",
      },
    mainImage2:{
    height:"65%",
    width:"100%",
    position:"relative",
    bottom:"5%"
    
    // position:"relative",


    },
    container2:{
    flexDirection:"column",
    alignItems:"center",
    justifyContent:"center",
    // marginBottom:"15%",
    gap:25,
    top:-80



    },
    heading2:{
        fontSize:29,
        color:"#fff",
        fontWeight:"900",
        width:"70%",
        textAlign:"center"
      
      
      
    },
    line11:{
    marginTop:4

    }
    
  });
export default Start3