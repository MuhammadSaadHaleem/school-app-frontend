import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react'
import { View, Text, StyleSheet, Image, Dimensions, TouchableOpacity, ImageBackground } from 'react-native';
import {
    heightPercentageToDP as hp,
    widthPercentageToDP as wp
} from 'react-native-responsive-screen';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';


const Learning = () => {

    const navigate = useNavigation()
    const handleBack = () => {
        navigate.goBack()
    }

    const [rate, setRate] = useState("4.8 rate")
    const [user, setUser] = useState("4.2k user")
    const [projects, setProjects] = useState("340 Project")

    return (
        <View style={styles.container} >

            <ImageBackground
                source={require("../assets/Learning1.png")}
                style={styles.image}
            >
                <Text style={styles.imageText}>Learn Library Consept</Text>
                <Text style={styles.imageText1}>Learn Concept in Library  </Text>

            </ImageBackground>

            <TouchableOpacity onPress={handleBack}>
                <IoniconsIcon name="arrow-back" size={30} color="white" style={styles.backIcon} />
            </TouchableOpacity>

            <View style={styles.statsBar}>
                <Text style={styles.statText}>{rate}</Text>
                <Text style={styles.statText}>{user}</Text>
                <Text style={styles.statText}>{projects}</Text>
            </View>

            <View style={styles.textContainer}>

                <Text style={styles.heading}> Synopsis</Text>
                <Text style={styles.descriptionText}>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.</Text>

            </View>

            <View>
                <TouchableOpacity onPress={() => navigate.navigate("QuizRightAnswer")}>
                    <View style={styles.editProfileBox}>
                        <Text style={styles.editProfile}>Start Learning</Text>
                    </View>
                </TouchableOpacity>

            </View>
        </View>
    )
}

export default Learning

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',

    },

    image: {
        width: wp("100%"),
        height: hp("40%"),
        top: "-35%"
    },
    backIcon: {
        right: "38%",
        top: -500,
        position: "absolute"

    },
    imageText: {
        color: 'white',
        fontSize: 30,
        fontWeight: 'bold',
        top: "60%",
        textAlign: "center"
    },

    imageText1: {
        color: 'white',
        fontSize: 20,
        top: "58%",
        textAlign: "center"
    },

    descriptionText: {
        width: wp("90%"),
        color: "#707A8D"
    },
    heading: {
        fontWeight: "bold",
        fontSize: 30,
        marginBottom: "5%"
    },

    textContainer: {

        marginTop: "-50%",
        top: "16%"
    },

    editProfileBox: {
        // Border color for the box
        borderWidth: 1, // Border width for the box
        borderRadius: 5, // Border radius for the box
        padding: 5, // Padding for the box content // Adjust the marginTop as needed
        backgroundColor: "#19245D",
        width: 320,
        height: 50,
        borderRadius: 30,
        top: 220,
        marginTop: "-18%"
    },

    editProfile: {
        top: '-5%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 10,
        fontSize: 18
    },
    statsBar: {
        flexDirection: 'row',
        backgroundColor: "#19245D",
        width: 320,
        height: 50,
        marginTop: hp('-20%'),
        textAlign:"center",
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 30,
        top:"-20%"


    },
    statText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 16,
        marginRight:"10%",
        left: 13
    },
})