import React from 'react';
import { View, Text, StyleSheet, Image, Dimensions, TouchableOpacity, ImageBackground } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { FontAwesome } from '@expo/vector-icons'; // Assuming you are using Expo
import { useNavigation } from '@react-navigation/native';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';



const { width, height } = Dimensions.get('window');

const Help = () => {

    React.useLayoutEffect(() => {
        navigation.setOptions({
            headerShown: false,
        });
    }, [navigation]);

    const navigation = useNavigation();
    const handleBack = () => {
        navigation.goBack()
    }

    return (
        <View style={styles.container}>
            <LinearGradient colors={["#72D8FE", "#2CB4EC"]} style={styles.background}>

                <TouchableOpacity onPress={handleBack}>
                    <IoniconsIcon name="arrow-back" size={30} color="#000000" style={styles.backIcon} />
                </TouchableOpacity>

                <View style={styles.maindiv}>
                    <Text style={styles.maintext}>Need {'\n'} Help {'\n'} With? </Text>
                    <Image source={require('../assets/1 2.png')} resizeMode='cover' style={styles.image5} />
                </View>

                <View style={styles.secondDiv}>
                    <LinearGradient colors={["#72D8FE", "#AEE7FF"]} style={styles.secondDiv}>
                        <Text style={styles.heading}>Ask a Question</Text>
                        <View style={styles.thirdDiv}>
                            <TouchableOpacity style={styles.smallDiv} onPress={() => navigation.navigate('TypeYourQuestion')}>
                                <FontAwesome name="keyboard-o" size={20} color="white" />

                            </TouchableOpacity>
                            <TouchableOpacity style={styles.smallDiv} onPress={() => navigation.navigate('CameraScreen')}>
                                <FontAwesome name="camera" size={20} color="white" />

                            </TouchableOpacity>

                        </View>
                    </LinearGradient>

                </View>



            </LinearGradient>





            <ImageBackground
                source={require('../assets/Rectangle 266.png')} // Replace with the actual path to your image
                style={styles.backgroundImage}
                imageStyle={{ borderRadius: 14 }}
            >


                <View style={styles.innerDiv} >
                    <Text style={styles.heading2}> Get unlimited access today! </Text>


                    <View style={styles.paraDiv}>
                        <Text style={styles.para}>
                            upgrade your learning with unlimited {'\n'} access to premium per...
                        </Text>

                        <Image source={require('../assets/toy.png')} resizeMode='cover' style={styles.image6} />

                    </View>

                </View>


            </ImageBackground>



        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',

    },
    background: {
        width: '100%', // Set width to 100% of the screen
        alignItems: 'center',
        position: "relative",
        bottom: 70,
        height: "70%"

    },
    backgroundImage: {
        resizeMode: 'cover',
        height: 165,
        width: '95%',
        borderRadius: 20,
        marginLeft: 17


    },
    heading: {
        fontSize: 26,
        color: "#FFFFFF",
        fontWeight: "900"



    },
    heading2: {
        fontSize: 22,
        color: "#FFFFFF",
        fontWeight: "900"



    },


    maindiv: {
        flexDirection: 'row',
        height: 300,
        justifyContent: 'center',
        alignItems: 'center',
        // borderWidth: 2,
        width: '100%',
        marginTop: 70,
    },
    innerDiv: {
        flexDirection: 'column',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        // borderWidth: 2,
        width: '100%',
        marginTop: 20,
        padding: 10

    },
    smallDiv: {
        height: 37,
        width: 113,
        backgroundColor: '#19245D',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5,
        marginRight: 20
    },
    thirdDiv: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 20,
        // alignItems:"center"

    },
    secondDiv: {
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        // borderWidth: 2,
        borderRadius: 25,
        // backgroundColor: '#AEE7FF',
        width: '100%',
        height: 150,
        marginTop: 20
    },
    maintext: {
        fontSize: 34,
        fontWeight: 'bold',
        marginLeft: 30,
        color: '#19245D',
        marginTop: 50,
    },
    image5: {
        height: '100%',
        width: '65%',
        marginRight: 30,
        top: "8%"
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 10,
    },
    description: {
        fontSize: 16,
        color: '#555',
        textAlign: 'center',
    },
    paraDiv: {
        marginTop: 10,
        flexDirection: "column",
        width: "100%"

    },
    para: {
        color: "#FFFFFF",
        fontSize: 16,
        fontWeight: "200",

    },
    image6: {
        position: "relative",
        left: 250,

    },
    backIcon: {
        right: "40%",
        top: 130
    }
});

export default Help;