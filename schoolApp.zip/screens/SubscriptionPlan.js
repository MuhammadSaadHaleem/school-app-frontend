import React from 'react'
import { View, Text, Button, StyleSheet, Image, Pressable, Dimensions, TouchableOpacity, ImageBackground, } from 'react-native';
import { Searchbar, Card } from 'react-native-paper';
import { LinearGradient } from 'expo-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome'; // Replace FontAwesome with the icon library of your choice
import IoniconsIcon from 'react-native-vector-icons/Ionicons';
import IconVisa from 'react-native-vector-icons/MaterialCommunityIcons'; // Import from MaterialCommunityIcons library
import { HomeScreenMain } from './HomeScreen';
import { useNavigation } from '@react-navigation/native';



const { width, height } = Dimensions.get('window');

export const SubscriptionPlan = () => {

    const navigation = useNavigation();
    const handleBack = () => {
        navigation.goBack()
    }
    return (
        <View
            style={styles.container}>

            <View>
                <TouchableOpacity onPress={handleBack}>
                <IoniconsIcon name="arrow-back" size={30} color="black" style={styles.backIcon} right= "500%" marginBottom="5%" />

                </TouchableOpacity>
            </View>
            <Text style={styles.text1}>Choose a plan </Text>
            <Text style={styles.text12}>Monthly or yearly? it’s your call </Text>

            <Image
                style={styles.card}
                source={require('../assets/Rectangle 266.png')}
            >
            </Image>
            <Image
                style={styles.card}
                source={require('../assets/Rectangle 266.png')}
            />

            <Text style={styles.textOnImage}>Monthly</Text>
            <Text style={styles.textOnImage1}>$15.00</Text>

            <Text style={styles.textOnImage2}>Annual</Text>
            <Text style={styles.textOnImage21}>$175.00</Text>

            <Text style={styles.text2}>Payment method </Text>

            <LinearGradient
                colors={['#72D8FE', '#2CB4EC']}
                style={styles.cardGradient}
            >

                <View style={styles.gradientContent}>
                    <View style={styles.row}>
                        <Icon name="credit-card" size={20} color="#2A3447" style={styles.icon} />
                        <Text style={styles.gradientText}>Credit/debit card</Text>
                    </View>

                    <View style={styles.row}>
                        <Icon name="credit-card" size={20} color="#2A3447" style={styles.icon} />
                        <Text style={styles.gradientText}>.....8302</Text>
                    </View>

                    <View style={styles.row}>
                        <Icon name="credit-card" size={20} color="#2A3447" style={styles.icon} />
                        <Text style={styles.gradientText}>New card</Text>
                    </View>
                </View>
            </LinearGradient>


            <View style={styles.row}>
                <Icon name="google-wallet" size={20} color="#2A3447" style={styles.icon} />
                <Text style={styles.gradientText}>Apple pay</Text>
            </View>


            <TouchableOpacity onPress={() => { }}>
                <View style={styles.editProfileBox}>
                    <Text style={styles.editProfile}>Play</Text>
                </View>
            </TouchableOpacity>

        </View>


    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },

    text1: {
        fontSize: 30,
        color: '#2A3447',
        width: '80%',
        marginTop: 0.15,
        textAlign: 'center',
        fontWeight: "bold",
        marginLeft: "-42%",
        width: "60%"
    },

    text12: {
        fontSize: 16,
        color: '#565656',
        width: '80%',
        marginTop: 2,
        textAlign: 'center',
        marginLeft: "-36%",
        width: "60%"
    },



    card: {
        marginTop: 20,
        marginBottom: -2,
        width: '90%',
        height: 120,
        borderRadius: 30,
        overflow: 'hidden',
    },
    textOnImage: {
        position: 'absolute',
        top: "29.5%", // Adjust the top position as needed
        left: 50, // Adjust the left position as needed
        color: 'white', // Change the text color
        fontSize: 22, // Adjust the font size
        // Adjust the font weight
    },

    textOnImage1: {
        position: 'absolute',
        top: "33%", // Adjust the top position as needed
        left: 50, // Adjust the left position as needed
        color: 'white', // Change the text color
        fontSize: 35, // Adjust the font size
        fontWeight: "bold" // Adjust the font weight
    },

    textOnImage2: {
        position: 'absolute',
        top: "46.5%", // Adjust the top position as needed
        left: 50, // Adjust the left position as needed
        color: 'white', // Change the text color
        fontSize: 22, // Adjust the font size
        // Adjust the font weight
    },

    textOnImage21: {
        position: 'absolute',
        top: "50%", // Adjust the top position as needed
        left: 50, // Adjust the left position as needed
        color: 'white', // Change the text color
        fontSize: 35, // Adjust the font size
        fontWeight: "bold" // Adjust the font weight
    },


    text2: {
        fontSize: 20,
        color: '#19245D',
        width: '80%',
        marginTop: 15,
        textAlign: 'center',
        fontWeight: "bold",
        marginLeft: "-50%",
        width: "60%"
    },

    cardGradient: {
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: height * 0.01,
        marginBottom: height * 0.005,
        width: '90%',
        height: height * 0.15,
        borderRadius: 15,
        overflow: 'hidden',
    },

    gradientText: {
        fontSize: 18,
        color: '#19245D',
        fontWeight: 'bold',
    },

    gradientContent: {
        marginTop: 10,
        marginRight: 150,

    },

    row: {
        flexDirection: 'row',
        marginBottom: 10,
    },

    icon: {
        marginRight: 10,
    },

    gradientText: {
        fontSize: 16,
        color: '#2A3447',
        fontWeight: 'bold',

    },

    editProfileBox: {
        // Border color for the box
        borderWidth: 1, // Border width for the box
        borderRadius: 5, // Border radius for the box
        padding: 5, // Padding for the box content // Adjust the marginTop as needed
        backgroundColor: "#19245D",
        width: 200,
        height: 40,
        borderRadius: 30,
        top: 20
    },

    editProfile: {
        top: '-5%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 3,
        fontSize: 20
    },

    
})