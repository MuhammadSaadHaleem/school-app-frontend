import React from 'react'
import { View, Text, Button, StyleSheet, Image, Pressable, TextInput, TouchableOpacity } from 'react-native';
import Icon from 'react-native-ico-material-design';
import { LinearGradient } from 'expo-linear-gradient';
import CheckBox from 'expo-checkbox';
import { useNavigation } from '@react-navigation/native';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';



export const SignIn = () => {

    // const navigation = useNavigation()
    // const handleBack = () => {
    //     navigation.goBack()
    // }
    const navigation = useNavigation();
    const handleBack = () => {
        navigation.goBack()
    }

    const [isChecked, setChecked] = React.useState(false)
    return (
        <View style={styles.container}>


            {/* <View>
                <TouchableOpacity onPress={handleBack}>

                    <Text >SAad</Text>

                </TouchableOpacity>
            </View> */}

            <View style={styles.cardContainer}>
                
                <LinearGradient
                    colors={['#72D8FE', '#2CB4EC']}
                    style={styles.cardGradient}
                />


                <TouchableOpacity onPress={handleBack}>
                    <IoniconsIcon name="arrow-back" size={30} color="black" style={styles.backIcon} />
                </TouchableOpacity>
                
                <Image
                    style={styles.image}
                    source={require('../assets/Saly-10.png')}
                    resizeMode="contain"
                >
                </Image>
            </View>
            
            <View style={styles.signin}>

            <Text style={styles.signText}>SIGN IN</Text>
            </View>

            <TextInput
                style={styles.input}
                placeholder="Username"
            // Additional TextInput props as needed
            >

            </TextInput>

            <TextInput
                style={styles.input}
                placeholder="Password"
                secureTextEntry  // Use this if it's a password input
            // Additional TextInput props as needed
            />

            <View style={styles.checkboxContainer}>
                <CheckBox value={isChecked} onValueChange={() => setChecked(!isChecked)} />
                <Text style={styles.checkboxText}>Remember me</Text>
                <Text style={styles.forgotPasswordText}>Forgot Password?</Text>


            </View>

            <TouchableOpacity onPress={() => navigation.navigate("HomeScreen")}>
                <View style={styles.editProfileBox}>
                    <Text style={styles.editProfile}>SIGN IN</Text>
                </View>
            </TouchableOpacity>

            <View style={styles.creatAnAccount}>
                <Text style={styles.checkboxText} onPress={() => navigation.navigate('SignUp')}>Create an account</Text>
                <Text style={styles.forgotPasswordText}>Continue as a guest</Text>


            </View>

            <View style={styles.socialButtonsContainer}>
                {/* Google Sign In Button */}
                <TouchableOpacity style={styles.googleButton}>
                    <IoniconsIcon name="logo-google" size={20} color="white" />
                    <Text style={styles.socialButtonText}> Google</Text>
                </TouchableOpacity>

                {/* Facebook Sign In Button */}
                <TouchableOpacity style={styles.facebookButton}>
                    <IoniconsIcon name="logo-facebook" size={20} color="white" />
                    <Text style={styles.socialButtonText}> Facebook</Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',

    },
    cardContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
    },

    cardGradient: {
        backgroundColor: 'transparent', // Set the background to transparent so that the gradient is visible
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        borderRadius: 50,
        height: "40%",
        width: "100%",
        marginTop: "-15%",
    },

    image: {

        width: "60%",
        height: "80%",
        // borderRadius: 100,
        // backgroundColor: 'white', // Set your color for the circular box
        position: 'absolute',
        top: '-16%',
        left: '20%',
        


    },
    // signin:{
    //     borderWidth:2
    // },

    signText: {
        fontSize: 30,
        fontWeight: "bold",
        color: "#030303",
        marginTop: "50%",
        marginBottom: 20
    },

    input: {
        height: 40,
        borderColor: '#000000',
        borderWidth: 1,
        marginBottom: 10,
        paddingLeft: 10,
        width: '80%',
        borderRadius: 20,

    },
    checkboxContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 10,
    },

    checkboxText: {
        marginLeft: 10,
    },

    forgotPasswordText: {
        marginLeft: '22%',
        color: '#19245D',
    },

    creatAnAccount: {
        flexDirection: 'row',
        alignItems: 'center',
    },

    editProfileBox: {
        // Border color for the box
        borderWidth: 1, // Border width for the box
        borderRadius: 5, // Border radius for the box
        padding: 5, // Padding for the box content // Adjust the marginTop as needed
        backgroundColor: "#19245D",
        width: 320,
        height: 50,
        borderRadius: 30,
        top: 20,
        marginBottom: 40
    },

    editProfile: {
        top: '-5%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 10,
        fontSize: 18
    },

    socialButtonsContainer: {
        flexDirection: 'row',
        marginTop: 20,

    },

    googleButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#141414', // Google Blue
        padding: 10,
        borderRadius: 5,
        marginRight: 10,
        width: "30%"
    },

    facebookButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#19245D', // Facebook Blue
        padding: 10,
        borderRadius: 5,
        width: "35%"
    },

    socialButtonText: {
        color: 'white',
        marginLeft: 10,
        fontSize: 18,
        fontWeight: "bold"
    },

    backIcon: {
        right: "40%",
        top: 130
    }
})
