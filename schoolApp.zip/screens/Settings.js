import React from 'react'
import { View, Text, Button, StyleSheet, Image, Pressable } from 'react-native';
import Icon from 'react-native-ico-material-design';



export const Settings = () => {
    return (
        <View
            style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
            }}>
            <Text>Settings </Text>
            <Icon name="add-plus-button" height="40" width="40" />

        </View>
    )
}
