import React from "react";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ImageBackground,
  TouchableOpacity,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { AntDesign } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import IoniconsIcon from 'react-native-vector-icons/Ionicons';

const About = () => {

  const navigation = useNavigation()
  const handleBack = () => {
    navigation.goBack()
  }

  return (
    <View style={styles.container}>
      <View style={styles.coinContainer}>


      <View style={styles.backButton}>
                <TouchableOpacity onPress={handleBack}>
                    <IoniconsIcon name="arrow-back" size={30} color="black" style={styles.backIcon} />
                </TouchableOpacity>
            </View>

        <Image
          source={require("../assets/images/coin.png")}
          resizeMethod="contain"
          style={styles.coinStyle}
        />
      </View>
      <View style={styles.resultCont}>
        <Text style={styles.resultText}>Hi, Wilson Mark </Text>
      </View>

      <LinearGradient colors={["#72D8FE", "#2CB4EC"]} style={styles.firstMain}>
        <View style={styles.firstInner}>
          <Text style={styles.firstText}>
            What would you like to learn today
          </Text>

          <TouchableOpacity style={styles.btn}>
            <Text style={styles.heading14}>Get Started</Text>
          </TouchableOpacity>
        </View>
        <Image
          source={require("../assets/images/cute.png")}
          resizeMethod="contain"
          style={styles.toy8}
        />
      </LinearGradient>

      <View style={styles.lastMain}>
        <View style={styles.lastMainHead}>
          <Text style={styles.text8}>For You</Text>
          <Text style={styles.text9}>See All</Text>
        </View>

        <View style={styles.main}>
          <View style={styles.lastMainLast}>
            <ImageBackground
              source={require("../assets/images/bg22.png")}
              style={styles.topImg1}
              imageStyle={{
                borderTopLeftRadius: 8,
                borderTopRightRadius: 8,
                borderBottomLeftRadius: 8,
                borderBottomRightRadius: 8,
              }}
            >
              <Text style={styles.text1}>Introduce</Text>
              <Text style={styles.text2}>Basic whats is Cours?</Text>
              <Text style={styles.text3}>
                Science is Widely uses program dynamic websites
              </Text>

              <View style={styles.secondDiv}>
                <Text style={styles.text3}>30 mins</Text>

                <TouchableOpacity style={styles.circle1}>
                  <AntDesign name="caretright" size={15} color="black" />
                </TouchableOpacity>
              </View>
            </ImageBackground>
          </View>

          <View style={styles.lastMainLast1}>
            <ImageBackground
              source={require("../assets/images/bg23.png")}
              style={styles.topImg2}
              imageStyle={{
                borderTopLeftRadius: 8,
                borderTopRightRadius: 8,
                borderBottomLeftRadius: 8,
                borderBottomRightRadius: 8,
              }}
            >
              <Text style={styles.text4}>Join your class</Text>

              <View style={styles.flexDiv}>
                <Image
                  source={require("../assets/images/img10.png")}
                  resizeMethod="contain"
                  style={styles.img10}
                />
                <Image
                  source={require("../assets/images/img11.png")}
                  resizeMethod="contain"
                  style={styles.img11}
                />
                <Image
                  source={require("../assets/images/img12.png")}
                  resizeMethod="contain"
                  style={styles.img12}
                />
                <Image
                  source={require("../assets/images/img13.png")}
                  resizeMethod="contain"
                  style={styles.img13}
                />

                <TouchableOpacity style={styles.circle2}>
                  <Text style={styles.text10}>12+</Text>
                </TouchableOpacity>
              </View>
            </ImageBackground>

            <ImageBackground
              source={require("../assets/images/bg24.png")}
              style={styles.topImg3}
              imageStyle={{
                borderTopLeftRadius: 8,
                borderTopRightRadius: 8,
                borderBottomLeftRadius: 8,
                borderBottomRightRadius: 8,
              }}
            >
              <Text style={styles.text6}>Article</Text>
              <Text style={styles.text7}>Tips for better team work</Text>
            </ImageBackground>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    height: hp(100),
  },
  coinContainer: {
    position: "absolute",
    right: wp(4),
    top: hp(5),
  },
  resultCont: {
    marginTop: hp(12),
  },
  resultText: {
    color: "#050505",
    fontSize: hp(3.5),
    fontWeight: "bold",
    marginBottom: hp(4),
  },
  mainContainer: {},

  mainBackground: {
    width: wp(100),
    height: hp(64),
    position: "relative",
    top: hp(14),
    flexDirection: "column",
    justifyContent: "center",
  },
  mainContent: {
    flexDirection: "column",
    alignItems: "center",
    gap: hp(2),
    position: "relative",
    bottom: hp(1.5),
    height: hp(45),
  },

  toy8: {
    height: hp(18),
    width: wp(38),
    position: "relative",
    right: wp(10),
    top: hp(3),
  },
  text1: {
    color: "#fff",
    fontWeight: "100",
    fontSize: hp(2),
    marginLeft: wp(2),
  },
  text2: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: hp(3),
    width: wp(50),
    marginLeft: wp(2),
  },
  text3: {
    color: "#fff",
    fontWeight: "200",
    fontSize: hp(2.2),
    textAlign: "left",
    width: wp(47),
    lineHeight: hp(3.2),
    marginLeft: wp(2),
    marginBottom: hp(0.2),
    marginTop: hp(0.8),
  },

  firstMain: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    // borderWidth: 2,
    gap: hp(4),
    borderRadius: 25,
    width: wp(93),
    height: hp(25),
  },
  firstInner: {
    flexDirection: "column",
    alignItems: "flex-start",
    width: wp(50),
    marginLeft: wp(18),
    position: "relative",
    top: hp(2),
  },
  btn: {
    marginTop: 15,
    marginBottom: -2,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    width: wp(27),
    height: hp(4.5),
    borderRadius: 4,
    fontWeight: "200",
    backgroundColor: "#19245D",
    marginLeft: wp(1),
    // borderWidth:2
  },
  heading14: {
    color: "#fff",
    fontSize: 15,
    // fontWeight:200,
  },

  firstText: {
    fontSize: 22,
    color: "#fff",
    fontWeight: "bold",
    width: wp(41),
    lineHeight: 27,
    textTransform: "capitalize",
  },
  lastMainHead: {
    //  borderWidth:2,
    flexDirection: "row",
    justifyContent: "center",
    gap: wp(61),
  },
  text10: {
    fontSize: wp(3),
  },
  lastMain: {
    marginTop: hp(2.5),
    //  borderWidth:2,
    borderColor: "red",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "space-around",

    height: hp(50),
    width: "100%",
  },

  btnFirst: {
    marginTop: 10,
    marginBottom: -2,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingLeft: wp(5),
    height: hp(7.6),
    borderRadius: 8,
    overflow: "hidden",
    marginHorizontal: wp(2.1),
    paddingVertical: hp(2),
    marginBottom: hp(1),
  },
  circle1: {
    // borderWidth:2,
    borderColor: "yellow",
    width: wp(11),
    height: hp(5.4),
    backgroundColor: "#fff",
    borderRadius: hp(53),
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  circle2: {
    // borderWidth:2,
    borderColor: "yellow",
    width: wp(8),
    height: hp(4.5),
    backgroundColor: "#fff",
    borderRadius: hp(53),
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  lastMainLast: {
    // borderWidth:2,
    height: hp(37),
    width: wp(56),
    marginLeft: wp(4),
  },
  lastMainLast1: {
    //  borderWidth:2,
    flexDirection: "column",
    gap: hp(2),
    marginRight: wp(4),
  },
  topImg1: {
    paddingLeft: wp(2),
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "flex-start",
    width: wp(53),
    height: hp(37),
  },
  main: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    width: wp(45),
    marginBottom: hp(3),
  },
  secondDiv: {
    flexDirection: "row",
    // justifyContent:"center",
    width: wp(20),
    gap: -45,
    marginTop: hp(2),
  },
  flexDiv: {
    flexDirection: "row",
    justifyContent: "center",
    gap: wp(-2),
    marginTop: hp(2),
  },
  topImg2: {
    flexDirection: "column",
    height: hp(17),
    alignItems: "center",
    padding: wp(2),
    width: wp(38),
  },
  text4: {
    color: "white",
    fontWeight: "bold",
    fontSize: wp(6.5),
    textTransform: "capitalize",
    textAlign: "left",
    marginRight: wp(5),
  },
  topImg3: {
    flexDirection: "column",
    paddingHorizontal: wp(2),
    height: hp(16.5),
  },
  text6: {
    color: "#fff",
    fontSize: wp(5),
    marginTop: hp(1.2),
    marginLeft: wp(2),
  },
  text7: {
    color: "#fff",
    fontWeight: "bold",
    marginTop: hp(1.5),
    fontSize: wp(5.2),
    width: wp(27),
    textTransform: "capitalize",
    marginLeft: wp(2),
  },
  text8: {
    color: "#000",
    fontWeight: "bold",
    fontSize: wp(5),
  },
  text9: {
    fontWeight: "bold",
    fontSize: wp(5),
    color: "#263238",
  },
  pauseStyle: {
    height: hp(2.5),
  },
  backButton: {
    position: "absolute",
    top: "11%"
  },
  backIcon: {
    left: -300,

},


});
export default About;