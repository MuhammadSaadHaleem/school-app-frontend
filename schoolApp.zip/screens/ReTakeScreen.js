import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet, Image, Alert } from 'react-native';
import { Camera, CameraType } from 'expo-camera';

export const ReTakeScreen = () => {
    const [hasPermission, setHasPermission] = useState(null);
    const [camera, setCamera] = useState(null);
    const [imageUri, setImageUri] = useState(null);
    const [type, setType] = useState(CameraType.back);
  
    useEffect(() => {
      (async () => {
        const { status } = await Camera.requestCameraPermissionsAsync();
        setHasPermission(status === 'granted');
      })();
    }, []);
  
    
  
    function toggleCameraType() {
      setType(current => (current === CameraType.back ? CameraType.front : CameraType.back));
    }
  
    const takePicture = async () => {
      try {
        if (camera) {
          const photo = await camera.takePictureAsync();
          setImageUri(photo.uri);
        } else {
          Alert.alert('Error', 'Camera is not available.');
        }
      } catch (error) {
        Alert.alert('Error', 'Failed to take picture.');
      }
    };
  
    const reTakePicture = async () => {
      setImageUri(null);
      setCamera(null)
  
      takePicture()
     
    };
  
    const uploadImage = async () => {
      if (!imageUri) {
        Alert.alert('Error', 'Please take a picture first.');
        return;
      }
      const formData = new FormData();
      formData.append('image', {
        uri: imageUri,
        name: 'photo.jpg',
        type: 'image/jpeg',
      });
  
      try {
        const response = await fetch('YOUR_BACKEND_API_ENDPOINT', {
          method: 'POST',
          body: formData,
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });
  
        if (response.ok) {
          Alert.alert('Success', 'Image uploaded successfully.');
        } else {
          Alert.alert('Error', 'Failed to upload image.');
        }
      } catch (error) {
        console.error('Error uploading image:', error);
        Alert.alert('Error', 'Failed to upload image.');
      }
    };
  
    if (hasPermission === null) {
      return <View />;
    }
    if (hasPermission === false) {
      return <Text>No access to camera</Text>;
    }
  
    return (
      <View style={{ flex: 1 }}>
        <Camera
          style={{ flex: 1 }}
          type={Camera.Constants.Type.back}
          ref={(ref) => setCamera(ref)}
        >
          {imageUri ? (
            <View style={{ flex: 1 }}>
              <Image source={{ uri: imageUri }} style={{ flex: 1 }} />
              <View style={styles.retakeButtonContainer}>
                <Button title="Re Take Picture" onPress={reTakePicture} />
                <Button title="Upload Image" onPress={uploadImage} />
              </View>
            </View>
          ) : (
            <View style={styles.buttonContainer}>
              <Button title="Take Picture" onPress={takePicture} />
              {/* <Button title="Flip Camera" onPress={toggleCameraType} /> */}
            </View>
          )}
        </Camera>
      </View>
    );
  };
  
  const styles = StyleSheet.create({
    buttonContainer: {
      flex: 1,
      flexDirection: 'coloumn',
      justifyContent: 'center',
      alignItems: 'flex-end',
      paddingBottom: 20,
    },
    retakeButtonContainer: {
      position: 'absolute',
      bottom: 20,
      alignSelf: 'center',
    },
  });
