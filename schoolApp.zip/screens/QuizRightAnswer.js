import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ImageBackground } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';

const QuizRightAnswer = () => {
    const navigation = useNavigation();
    const [correctOption, setCorrectOption] = useState('');
    // Assume data from API has the correct option as 'A', 'B', or 'C'
    const correctOptionFromAPI = 'A'; // Example correct option from API

    useEffect(() => {
        // Simulate fetching correct option from API
        // Replace this with actual API call in your application
        // For demonstration purpose, I'm setting the correct option after 1 second
        const timeout = setTimeout(() => {
            setCorrectOption(correctOptionFromAPI);
        });

        return () => clearTimeout(timeout);
    }, []);

    const handleBack = () => {
        navigation.goBack();
    };

    return (
        <View style={styles.container}>
            <View style={styles.image}>
                <ImageBackground
                    source={require('../assets/QuizRightAnswer.png')}
                    style={styles.card}
                    resizeMode='contain'
                />
                <View style={styles.backButton}>
                    <TouchableOpacity onPress={handleBack}>
                        <IoniconsIcon name="arrow-back" size={30} color="white" style={styles.backIcon} />
                    </TouchableOpacity>
                </View>
            </View>

            <View style={styles.mainTextArea}>
                <Text style={styles.mainText}>PREDICT THE TOP LOSER (for tomorrow) across these indices</Text>

            </View>


            <View style={styles.answerContainer}>
                <TouchableOpacity style={[styles.answer, correctOption === 'A' && styles.correctAnswer]}>
                    <Text style={styles.answerText}>A.   NIFTY50   {correctOption === 'A' && '(Correct Answer)'}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.answer, correctOption === 'B' && styles.correctAnswer]}>
                    <Text style={styles.answerText}>B.   NIFTYNEXT50   {correctOption === 'B' && '(Correct Answer)'}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.answer, correctOption === 'C' && styles.correctAnswer]}>
                    <Text style={styles.answerText}>C.   NIFTYBANK {correctOption === 'C' && '(Correct Answer)'}</Text>
                </TouchableOpacity>
            </View>

            <View style={styles.result}>
            <TouchableOpacity onPress={() => navigation.navigate("QuizSolve")}>
                <View style={styles.editProfileBox}>
                    <Text style={styles.editProfile}>Result</Text>
                </View>
            </TouchableOpacity>
            </View>
        </View>
    );
}

export default QuizRightAnswer;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    image: {
        width: '100%',
        height: "35%",
        top: "-1.5%",
        position: "absolute"
    },
    card: {
        width: '100%',
        height: "100%",
        overflow: 'hidden',
    },
    backButton: {
        position: "absolute",
        top: "30%",
        left: "7%",
    },
    backIcon: {
        left: "5%",
    },
    mainText: {
        fontSize: 30,
        fontWeight: "bold",
        color: "#191D63",
        textAlign: "center",
        width: 350,
    },
    mainTextArea: {
        // borderWidth: 2,
        top: "13%",
        padding: 20,
    },
    answerContainer: {
        marginTop: 70,
        top:"5%"
    },
    answer: {
        // backgroundColor: '#FFFFFF',
        padding: 20,
        marginBottom: 10,
        // borderWidth: 1,
        // borderColor: '#CCCCCC',
        borderRadius: 10,
    },
    answerText: {
        fontSize: 20,
        fontWeight:"bold"

    },
    correctAnswer: {
        backgroundColor: '#4CAF50', // Green color for correct answer
    },

    editProfileBox: {
        // Border color for the box
        borderWidth: 1, // Border width for the box
        borderRadius: 5, // Border radius for the box
        padding: 5, // Padding for the box content // Adjust the marginTop as needed
        backgroundColor: "#19245D",
        width: 320,
        height: 50,
        borderRadius: 30,
        top: 20,
        marginBottom: 40
    },

    editProfile: {
        top: '-5%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 10,
        fontSize: 18
    },
    result:{
        top:70
        
    }
});
