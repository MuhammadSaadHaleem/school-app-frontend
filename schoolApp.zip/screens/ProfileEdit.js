import React from 'react';
import { View, Text, StyleSheet, Dimensions, TouchableOpacity } from 'react-native';
import { IconButton, Card } from 'react-native-paper';
import { LinearGradient } from 'expo-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { useNavigation } from '@react-navigation/native';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';


const { height } = Dimensions.get('window');

export const ProfileEdit = () => {

    React.useLayoutEffect(() => {
        navigation.setOptions({
            headerShown: false,
        });
    }, [navigation]);

    const navigation = useNavigation();
    const handleBack = () => {
        navigation.goBack()
    }

    const menuItems = [
        { text: 'Edit Profile', icon: 'user' },
        { text: 'Change Password', icon: 'lock' },
        { text: 'Security', icon: 'shield' },
        { text: 'Subscription Plan', icon: 'credit-card' },
        { text: 'About', icon: 'info-circle' },
        { text: 'FAQ', icon: 'question-circle' },
        { text: 'Logout', icon: 'sign-out' }
    ];


    const handleMenuItemPress = (text) => {
        // Handle onPress action for each menu item
        if (text === 'Subscription Plan') {
            // Navigate to the SubscriptionPlan screen
            navigation.navigate('SubscriptionPlan');
        }
        else if (text === 'Edit Profile') {
            navigation.navigate("EditProfile")
        }
        else if(text==='About'){
            navigation.navigate('About')
        }
        else if (text==="Security"){
            navigation.navigate("SubscriptionPlanUnpaid")
        }
        else if (text==="FAQ"){
            navigation.navigate("FAQ")
        }
        // Add similar conditions for other menu items if needed
    };


    return (
        <View style={styles.container}>
            {/* <IconButton
                icon="menu" // Replace with the icon name you want for the side menu
                size={30}
                onPress={() => {
                    navigation.navigate('ProfileEdit'); // Replace 'YourScreenName' with the actual name of the screen you want to navigate to

                }}
                style={styles.icon}
            /> */}

            <View style={styles.cardContainer}>


                <LinearGradient
                    colors={['#72D8FE', '#2CB4EC']}
                    style={styles.cardGradient}
                />

                
                <View style={styles.circleBox}></View>
            </View>

            <View>
            <TouchableOpacity onPress={handleBack}>
                    <IoniconsIcon name="arrow-back" size={30} color="white" style={styles.backIcon} />
                </TouchableOpacity>
            </View>

            <View style={styles.profile}>
            <Text style={styles.name}>Profile </Text>
            <Text style={styles.email} >www.@gmail.com</Text>
            </View>

            <View>
            <TouchableOpacity onPress={{}}>
                <View style={styles.editProfileBox}>
                    <Text style={styles.editProfile}>Edit Profile</Text>
                </View>
            </TouchableOpacity>
            </View>

            <View style={styles.menuContainer}>
                {menuItems.map((item, index) => (
                    <TouchableOpacity key={index} onPress={() => handleMenuItemPress(item.text)}>
                        <View style={styles.menuItem}>
                            <LinearGradient
                                colors={['#72D8FE', '#2CB4EC']}
                                style={styles.menuItemGradient}
                            >
                                <Icon name={item.icon} size={24} color="#fff" style={styles.icon} />
                            </LinearGradient>
                            <Text style={styles.menuText}>{item.text}</Text>
                        </View>
                    </TouchableOpacity>
                ))}
            </View>

        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    cardContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
    },
    profile:{
        // borderWidth: 1,
        top:"3%",
        alignItems:"center"
        
    },
    name: {
        fontSize: 25,
        fontWeight: "bold",
        top: "0%",
    },
    email: {

    },
    editProfileBox: {
        borderWidth: 1,
        borderRadius: 5,
        padding: 5,
        backgroundColor: "#19245D",
        width: 200,
        height: 30,
        borderRadius: 30,
        top: "60%",
        marginBottom: 20, // Adjust the marginBottom to create separation from the menu items
        height: 40
    },
    menuItemGradient: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderRadius: 50,
        marginVertical: -4,
        marginRight: "30%",
        top: "70%",
    },

    editProfile: {
        top: '-5%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 4,
        fontSize: 17
    },
    card: {
        marginTop: '-140%',
        marginBottom: height * 0.04,
        width: '100%',
        height: height * 0.35,
        borderRadius: 50,
        overflow: 'hidden',
        backgroundColor: 'red', // Set your background color here
    },
    cardGradient: {
        flex: 1,
        backgroundColor: 'transparent', // Set the background to transparent so that the gradient is visible
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        borderRadius: 50,
        height: "40%",
        width: "100%",
        marginTop: "-15%",
    },
    circleBox: {
        width: 140,
        height: 140,
        borderRadius: 100,
        backgroundColor: 'white', // Set your color for the circular box
        position: 'absolute',
        top: '27%',
        left: '45%',
        marginTop: -50,
        marginLeft: -55,
        

    },

    menuContainer: {
        marginTop: -200,
        // borderWidth: 1,
        top: "26%"

    },
    menuItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderRadius: 50,
        marginVertical: -2,
        marginRight: "30%",
    },
    icon: {
        marginRight: 2,


    },
    menuText: {
        fontSize: 18,
        color: 'black',
        margin: -20,
        marginTop: "14%",
        marginLeft: "-20%"
    },
    iconBackground: {
        borderRadius: "100%",
        padding: -50,
        marginRight: 200,
        left: 200
    },
    backIcon: {
        right: 150,
        top:-150
        
    }


});

export default ProfileEdit;
