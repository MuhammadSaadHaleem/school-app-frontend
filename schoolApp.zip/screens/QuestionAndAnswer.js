import { useNavigation } from '@react-navigation/native';
import React from 'react'
import { View, Text, StyleSheet, Image, Dimensions, TouchableOpacity, ImageBackground } from 'react-native';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';


const QuestionAndAnswer = () => {

  const navigate = useNavigation()
  const handleBack = () => {
    navigate.goBack()
  }


  const dummyData = [
    { question: "What is React Native?", answer: "React Native is a framework for building native applications using React." },
    { question: "How do you handle state in React?", answer: "State in React can be managed using the useState hook or by using class components and setState." },
    { question: "What is React Native?", answer: "React Native is a framework for building native applications using React." },
    { question: "How do you handle state in React?", answer: "State in React can be managed using the useState hook or by using class components and setState." },

  ]




  return (
    <View style={styles.container}>

      <View style={styles.image}>
        <ImageBackground
          source={require('../assets/QuestionAndAnswer.png')}
          style={styles.card}
          resizeMode='contain'>

        </ImageBackground>


        <View style={styles.backButton}>
          <TouchableOpacity onPress={handleBack}>
            <IoniconsIcon name="arrow-back" size={30} color="white" style={styles.backIcon} />
          </TouchableOpacity>
        </View>
      </View>


      <View>
        <Text style={styles.mainText}>
          Question And Answer
        </Text>
      </View>


      <View style={styles.QuestionAndAnswer}>

        {dummyData.map((item, index) => {

          return (
            <>
              <Text style={styles.question}>Q   {item.question}</Text>
              <Text style={styles.answer}><Text style={styles.answerA}>A   </Text>{item.answer}</Text>

            </>

          )
        })}
      </View>

    </View>
  )
}

export default QuestionAndAnswer

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',

  },
  image: {
    width: '100%',
    height: "35%",
    top: "2.5%",
    // borderWidth:2,
    position: "absolute"
  },
  card: {

    width: '100%',
    height: "100%",
    overflow: 'hidden',
  },

  QuestionAndAnswer: {
    // borderWidth:2,
    margin: "5%",
    top: "17%"
  },
  backButton: {
    position: "absolute",
    top: "20%",
    left: "7%"
  },

  backIcon: {
    left: "5%"

  },
  question: {
    fontWeight: "bold",
    fontSize: 18,
    marginBottom: 10
  },

  answer: {
    fontSize: 16,
    marginBottom: 20

  },

  answerA: {
    fontSize: 16,
    fontWeight: "bold"

  },

  mainText: {
    fontSize: 30,
    fontWeight: "bold",
    color: "white"
  }


})