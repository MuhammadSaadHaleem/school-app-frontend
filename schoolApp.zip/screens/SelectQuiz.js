import React from 'react'
// import { useEffect, useState } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    Dimensions,
    TouchableOpacity,
    ImageBackground,
    FlatList
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { FontAwesome } from "@expo/vector-icons";
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');
const mathImage = require('../assets/Saly-42.png');
const playIcon = require('../assets/Vector (2).png');



const SelectQuiz = () => {


    const navigation = useNavigation();
    const handleBack = () => {
        navigation.goBack()
    }
    return (

        <>
            <Image
                source={require("../assets/image 37.png")}
                resizeMode="contain"
                style={styles.mainImage2}
            />

          



            <TouchableOpacity style={styles.cardGradient} onPress={() => navigation.navigate('Quiz')}>

                <ImageBackground
                    source={require('../assets/Rectangle 283.png')}
                    style={styles.card}
                    resizeMode='contain'
                >
                    <View style={styles.gradientContent1}>
                        <Image source={mathImage} style={styles.icon1} />

                        <Text style={styles.gradientText1}>QUIZ</Text>
                        <Image source={playIcon} style={styles.icon2} resizeMode="contain" />

                    </View>
                </ImageBackground>

            </TouchableOpacity>

            <TouchableOpacity style={styles.cardGradient} onPress={() => navigation.navigate('QuestionAndAnswer')}>

                <ImageBackground
                    source={require('../assets/Rectangle 284.png')}
                    style={styles.card}
                    resizeMode='contain'
                >
                    <View style={styles.gradientContent}>
                        <Image source={mathImage} style={styles.icon} />

                        <Text style={styles.gradientText}>WEEKLY MOCK TEST</Text>
                        <Image source={playIcon} style={styles.icon21} resizeMode="contain" />

                    </View>
                </ImageBackground>

            </TouchableOpacity>
            <TouchableOpacity style={styles.cardGradient} onPress={() => navigation.navigate('MonthlyCompetition')}>

                <ImageBackground
                    source={require('../assets/Rectangle 285.png')}
                    style={styles.card}
                    resizeMode='contain'
                >
                    <View style={styles.gradientContent}>
                        <Image source={mathImage} style={styles.icon} />

                        <Text style={styles.gradientText}>MONTHLY COMPLITITION</Text>
                        <Image source={playIcon} style={styles.icon22} resizeMode="contain" />

                    </View>
                </ImageBackground>

            </TouchableOpacity>




        </>






    )
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',

    },
    background: {
        width: '100%', // Set width to 100% of the screen
        alignItems: 'center',
        position: "relative",
        bottom: 70,
        height: "70%"

    },
    backgroundImage: {
        resizeMode: 'cover',
        height: 165,
        width: '95%',
        borderRadius: 20,
        marginLeft: 17


    },
    heading: {
        fontSize: 26,
        color: "#FFFFFF",
        fontWeight: "900"



    },
    heading2: {
        fontSize: 22,
        color: "#FFFFFF",
        fontWeight: "900"



    },

    backgroundImageStyle: {
        width: "100%"
    },


    maindiv: {
        flexDirection: 'row',
        height: 300,
        justifyContent: 'center',
        alignItems: 'center',
        // borderWidth: 2,
        width: '100%',
        marginTop: 70,
    },
    innerDiv: {
        flexDirection: 'column',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        // borderWidth: 2,
        width: '100%',
        marginTop: 20,
        padding: 10

    },
    smallDiv: {
        height: 37,
        width: 113,
        backgroundColor: '#19245D',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5,
        marginRight: 20
    },
    thirdDiv: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 20,
        // alignItems:"center"

    },
    secondDiv: {
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        // borderWidth: 2,
        borderRadius: 25,
        // backgroundColor: '#AEE7FF',
        width: '100%',
        height: 150
    },
    maintext: {
        fontSize: 34,
        fontWeight: 'bold',
        marginLeft: 30,
        color: '#19245D',
        marginTop: 50,
    },
    image5: {
        height: '100%',
        width: '65%',
        marginRight: 30,
    },



    // cardGradient: {
    //     flex: 1,
    //     backgroundColor: '#fff',
    //     alignItems: 'center',
    //     justifyContent: 'center',
    //     marginTop: height * 0.01,
    //     marginBottom: height * 0.005,
    //     width: '90%',
    //     height: height * 0.1,
    //     borderRadius: 15,
    //     overflow: 'hidden',
    // },
    cardGradient1: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: height * 0.01,
        marginBottom: height * 0.05,
        width: '90%',
        height: height * 0.1,
        borderRadius: 15,
        overflow: 'hidden',
    },

    gradientContent: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        marginRight: "10%",
    },
    gradientContent1: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        marginRight: "35%",
    },

    gradientText: {
        fontSize: 20,
        color: 'white',
        textAlign: 'center',
        fontWeight: 'bold',
    },

    gradientText1: {
        fontSize: 20,
        color: 'white',
        textAlign: 'center',
        fontWeight: 'bold',
        right: 26

    },
    icon: {
        width: 30,
        height: 40,
        marginRight: 8,
    },

    icon1: {
        width: 30,
        height: 40,
        right: 37,
    },


    icon2: {
        width: 30,
        height: 30,
        marginLeft: 40,
        left: 140

    },
    icon21: {
        width: 30,
        height: 30,
        marginLeft: 90,
        marginRight: -8
    },
    icon22: {
        width: 30,
        height: 30,
        marginLeft: 40,

    },

    card: {
        marginTop: 10,
        marginBottom: -2,
        width: '95%',
        height: 70,
        borderRadius: 10,
        overflow: 'hidden',
        marginLeft: 20
    },


});
export default SelectQuiz