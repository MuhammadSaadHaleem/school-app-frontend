import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';

const SubscriptionPlanUnpaid = () => {
    const navigation = useNavigation();
    const [selectedPlan, setSelectedPlan] = useState(null);

    const handleBack = () => {
        navigation.goBack();
    }

    const handlePlanSelection = (plan) => {
        setSelectedPlan(plan);
    }

    return (
        <View style={styles.container}>
            <TouchableOpacity onPress={handleBack} style={styles.backButton}>
                <IoniconsIcon name="arrow-back" size={30} color="black" />
            </TouchableOpacity>

            <View style={styles.content}>
                <Text style={styles.title}>Subscription Plan</Text>
                <Text style={styles.subtitle}>Monthly or yearly? it’s your call</Text>
                <Image source={require("../assets/bro.png")} style={styles.image} resizeMode='contain'/>


                <View style={styles.planContainer}>
                    <View style={[styles.checkbox, selectedPlan === "weekly" && styles.checked]} onTouchEnd={() => handlePlanSelection("weekly")}>
                        {selectedPlan === "weekly" && <IoniconsIcon name="checkmark" size={20} color="white" />}
                    </View>

                    <Text style={styles.planText} onTouchEnd={() => handlePlanSelection("weekly")}>Weekly</Text>
                    <Text style={styles.planText1} onTouchEnd={() => handlePlanSelection("weekly")}>$15.00/- </Text>

                </View>


                <View style={styles.planContainer}>
                    <View style={[styles.checkbox, selectedPlan === "monthly" && styles.checked]} onTouchEnd={() => handlePlanSelection("monthly")}>
                        {selectedPlan === "monthly" && <IoniconsIcon name="checkmark" size={20} color="white" />}
                    </View>

                    <Text style={styles.planText} onTouchEnd={() => handlePlanSelection("monthly")}>Monthly</Text>
                    <Text style={styles.planText1} onTouchEnd={() => handlePlanSelection("monthly")}>$25.00/-</Text>
                </View>


               


                <View style={styles.planContainer}>

                    <View style={[styles.checkbox, selectedPlan === "yearly" && styles.checked]} onTouchEnd={() => handlePlanSelection("yearly")}>
                        {selectedPlan === "yearly" && <IoniconsIcon name="checkmark" size={20} color="white" />}
                    </View>

                    <Text style={styles.planText} onTouchEnd={() => handlePlanSelection("yearly")}>Yearly</Text>
                    <Text style={styles.planText1} onTouchEnd={() => handlePlanSelection("yearly")}>$100.00/- </Text>


                </View>

                <TouchableOpacity onPress={() => navigation.navigate("HomeScreen")} style={styles.payNowButton}>
                    <Text style={styles.payNowText}>Pay Now</Text>
                </TouchableOpacity> 
            </View>
        </View>
    );
}

export default SubscriptionPlanUnpaid;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#ffffff',
    },
    backButton: {
        position: 'absolute',
        top: 100,
        left: 20,
        zIndex: 1,
    },
    content: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        top:40
    },
    title: {
        fontSize: 30,
        fontWeight: 'bold',
        marginBottom: 10,
    },
    subtitle: {
        fontSize: 20,
        marginBottom: 20,
    },
    image: {
        width: "80%",
        height: 200,
        marginBottom: 30,
    },
    planContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 20,
        borderWidth: 1,
        borderColor: '#19245D',
        borderRadius: 15,
        padding: "5%"
    },
    
    checkbox: {
        width: 24,
        height: 24,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#19245D',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 10,
    },
    checked: {
        backgroundColor: '#19245D',
    },
    planText: {
        fontSize: 25,
        color: '#19245D',
        fontWeight:"bold"
    },
    planText1: {
        fontSize: 25,
        color: '#19245D',
        fontWeight:"bold",
        marginLeft:60
    },
    payNowButton: {
        borderWidth: 1, // Border width for the box
        borderRadius: 5, // Border radius for the box
        padding: 5, // Padding for the box content // Adjust the marginTop as needed
        backgroundColor: "#19245D",
        width: 320,
        height: 50,
        borderRadius: 30,
        top: 20,
        marginBottom: 40
    },
    payNowText: {
        top: '-5%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 10,
        fontSize: 18
    },
});
