import React, { useEffect, useState } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    Dimensions,
    TouchableOpacity,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { FontAwesome } from "@expo/vector-icons";
import ProgressCircle from "react-native-progress-circle";
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { useNavigation } from "@react-navigation/native";
import IoniconsIcon from 'react-native-vector-icons/Ionicons';




const ParentalReports = () => {

    const navigation = useNavigation()
    const [progress, setProgress] = useState(30);
    useEffect(() => {
        // Replace this with your actual API call logic
        const fetchProgressFromAPI = async () => {
            try {
                // Make API call and get the progress value
                const response = await fetch("your_api_endpoint");
                const data = await response.json();
                setProgress(data.progress); // Update progress value
            } catch (error) {
                console.error("Error fetching progress:", error);
            }
        };

        // Call the function to fetch progress
        fetchProgressFromAPI();
    }, []); // Empty dependency array to run the effect only once on component mount

    const handleBack = () => {
        navigation.goBack()
    }

    return (
        <View style={styles.container}>


            <Image
                source={require("../assets/images/toy.png")}
                resizeMode="cover"
                style={styles.image9}
            />

          

            <LinearGradient colors={["#72D8FE", "#2CB4EC"]} style={styles.secondDiv}>
                <Text style={styles.heading}>

                    Parental Reports{"\n"}Show Overview
                </Text>
                <View style={styles.thirdDiv}>
                    <TouchableOpacity style={styles.smallDiv} onPress={() => navigation.navigate("TimeTable")}>
                        <Text style={styles.buttonInner}>Create A Time Table</Text>
                    </TouchableOpacity>

                    <Image
                        source={require("../assets/images/toy3.png")}
                        resizeMode="contain"
                        style={styles.image6}
                    />
                </View>
            </LinearGradient>

            <View style={styles.backButton}>
                <TouchableOpacity onPress={handleBack}>
                    <IoniconsIcon name="arrow-back" size={30} color="black" style={styles.backIcon} />
                </TouchableOpacity>
            </View>

            <View style={styles.fourDiv}>
                <View style={styles.fourFirst}>
                    <Text style={styles.heading2}>Show All Reports</Text>
                    <Text style={styles.para}>View All</Text>
                </View>

                <View style={styles.fourSecond}>
                    <View style={styles.fourSecondOne}>
                        <Text style={styles.heading3}>Quiz</Text>

                        <ProgressCircle
                            percent={25}
                            radius={44}
                            borderWidth={8}
                            color="#fff"
                            shadowColor="#72D8FE"
                            bgColor="#19245D"
                        >
                            <Text style={{ fontSize: 18, color: "white" }}>{"78%"}</Text>
                        </ProgressCircle>
                        <Text style={styles.para2}>Quiz Report</Text>
                    </View>

                    <View style={styles.fourSecondTwo}>
                        <Text style={styles.heading3}>Performance</Text>
                        <ProgressCircle
                            percent={25}
                            radius={44}
                            borderWidth={8}
                            color="#fff"
                            shadowColor="#19245D"
                            bgColor="#72D8FE"
                        >
                            <Text style={{ fontSize: 18, color: "white" }}>{"85%"}</Text>
                        </ProgressCircle>
                        <Text style={styles.para3}>Subject Counting</Text>
                    </View>
                </View>

                <View style={styles.fourSecond}>
                    <View style={styles.fourSecondOne}>
                        <Text style={styles.heading3}>Quiz</Text>

                        <Text style={styles.para2}>Quiz Report</Text>
                    </View>

                    <View style={styles.fiveSecondTwo}>
                        <Image
                            source={require("../assets/images/toy4.png")}
                            resizeMode="cover"
                            style={styles.image7}
                        />

                        <View style={styles.allReport}>
                            <Text style={styles.para4}>All Report</Text>
                            <Text style={styles.span}>
                                <FontAwesome
                                    name="map-marker"
                                    size={30}
                                    color="gray"
                                    style={styles.location1}
                                />
                                New York USA
                            </Text>
                        </View>

                        <View style={styles.paraDiv2}>
                            <View style={styles.innerParaDiv2}>
                                <Text style={styles.span}>Projects</Text>
                                <Text style={styles.span1}>27</Text>
                            </View>
                            <View style={styles.innerParaDiv2}>
                                <Text style={styles.span}>Quiz</Text>
                                <Text style={styles.span1}>243</Text>
                            </View>
                            <View style={styles.innerParaDiv2}>
                                <Text style={styles.span}>Subject</Text>
                                <Text style={styles.span1}>73</Text>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        </View>
    );
};


const styles = StyleSheet.create({
    container: {
        flex: 1,
        // justifyContent: "center",
        marginTop: hp(6),
        // height:"90%",
        alignItems: "center",
    },
    secondDiv: {
        flexDirection: "column",
        alignItems: "flex-start",
        // borderWidth: 2,
        borderRadius: 25,
        // backgroundColor: '#AEE7FF',
        width: "95%",
        paddingHorizontal: wp(5.8),
        marginLeft: wp(0.8),
        paddingTop: hp(2.2),
        height: hp(23),
        position: "relative",
        top: hp(2.3),
    },
    buttonInner: {
        color: "#fff",

        // marginBottom:5
    },
    smallDiv: {
        height: hp(5),
        width: wp(37),
        backgroundColor: "#19245D",
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 5,
        marginRight: wp(0.2),
    },
    heading: {
        fontSize: wp(7),
        color: "#19245D",
        fontWeight: "700",
    },
    heading2: {
        fontSize: 20,
        color: "#19245D",
        fontWeight: "700",
    },
    thirdDiv: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: hp(3.2),
        // alignItems:"center"
    },
    image6: {
        position: "relative",
        left: wp(19),
        bottom: hp(7),
        width: "30%",
        // height:"10%"
    },
    fourDiv: {
        // borderWidth: 2,
        width: "100%",
        marginTop: hp(5),
        paddingHorizontal: wp(2.8),
    },
    fourFirst: {
        // borderWidth: 2,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: wp(1.2),
        alignItems: "center",
        marginBottom: hp(3),
    },
    para: {
        color: "#B5B5B5",
        fontSize: wp(4.4),
        fontWeight: "200",
    },
    fourSecond: {
        flexDirection: "row",
        justifyContent: "space-between",
        // borderWidth: 2,
        width: "100%",
        gap: 6,
        height: "32%",
        marginBottom: wp(2.8),
        // borderRadius: 25,
    },
    fourSecondOne: {
        flexDirection: "column",
        alignItems: "center",
        width: "47%",
        // marginHorizontal:10,
        backgroundColor: "#19245D",
        borderRadius: 10,
    },
    fourSecondTwo: {
        flexDirection: "column",
        alignItems: "center",
        width: "50%",
        // marginHorizontal:10,
        backgroundColor: "#72D8FE",
        borderRadius: 10,
    },
    heading3: {
        fontSize: wp(4.8),
        color: "#fff",
        fontWeight: "700",
        marginBottom: wp(2.3),
        marginTop: hp(0.4)
    },
    para2: {
        color: "#fff",
        marginTop: hp(0.4),
    },
    para3: {
        color: "#19245D",
        marginTop: hp(0.4),
        fontWeight: "300",
    },
    para4: {
        color: "#19245D",
        marginTop: hp(1.1),
        fontWeight: "bold",
    },
    fiveSecondTwo: {
        flexDirection: "column",
        alignItems: "center",
        width: "50%",
        // marginHorizontal:10,
        backgroundColor: "#fff",
        borderRadius: 10,
    },
    paraDiv2: {
        flexDirection: "row",
        justifyContent: "space-between",
        // borderWidth:2,
        marginTop: hp(1.1),
        marginLeft: wp(3),
    },
    innerParaDiv2: {
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        marginRight: wp(4),
    },
    span: {
        color: "#A3AED0",
        fontWeight: "100",
        fontSize: wp(3.2),
    },
    span1: {
        color: "#19245D",
        fontWeight: "bold",
    },
    allReport: {
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
    },
    location1: {
        fontSize: wp(4.6),
        marginRight: wp(2),
    },
    image7: {
        position: "relative",
        top: hp(1.6),
    },
    image9: {
        position: "relative",
        top: hp(1.5),
        //  bottom:60,
        left: wp(40)



    },
    backButton: {
        position: "absolute",
        top: "2.5%",
        left:25
        
    },

    backIcon: {
       
    },
});

export default ParentalReports;