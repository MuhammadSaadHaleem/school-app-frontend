import React from "react";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ImageBackground,
  TouchableOpacity,
} from "react-native";
import { useState,useEffect } from "react";

const Result = () => {


 const [data,setData]=useState({
  imageUrl1:require("../assets/images/mainBackground.png"),
  message:"Congrates!",
  score:"90% Score",
  para:"It is a long established fact that a reader will be distracted by the readable content of a page",
  imageUrl:require("../assets/images/toy8.png"),
 });

//  useEffect(() => {
//   // Fetch data from the backend API here
//   const fetchData = async () => {
//     try {
//       const response = await fetch("YOUR_BACKEND_API_ENDPOINT");
//       const result = await response.json();
//       setData({
//         message: result.message,
//         score: result.score,
//         para: result.para,
//         imageUrl: result.imageUrl,
//       });
//     } catch (error) {
//       console.error("Error fetching data:", error);
//     }
//   };

//   fetchData();
// }, []);

  return (
    <View style={styles.container}>
      <View style={styles.coinContainer}>
        <Image
          source={require("../assets/images/coin.png")}
          resizeMethod="contain"
          style={styles.coinStyle}
        />
      </View>

      <View style={styles.resultCont}>
        <Text style={styles.resultText}> Result </Text>
      </View>

      <ImageBackground
        source={data.imageUrl1}
        style={styles.mainBackground}
        imageStyle={{ borderTopLeftRadius: 21, borderTopRightRadius: 21 }}
      >
        <View style={styles.mainContent}>
          <Image
            source={require("../assets/images/toy8.png")}
            resizeMethod="cover"
            style={styles.toy8}
          />
          <Text style={styles.text1}>{data.message}</Text>
          <Text style={styles.text2}>{data.score}</Text>
          <Text style={styles.text3}>{data.para}</Text>
        </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    // borderWidth: 2,
    flex: 1,
    alignItems: "center",
    height: hp(100),
  },
  coinContainer: {
    //   borderWidth:2,
    position: "absolute",
    right: wp(4),
    top: hp(5),
  },
  resultCont: {
    // borderWidth: 2,
    marginTop: hp(12),
  },
  resultText: {
    color: "#050505",
    fontSize: hp(3.5),
    fontWeight: "bold",
  },
  mainContainer: {
  borderWidth:3,



  },
  mainBackground: {
    // borderWidth: 3,
    width: wp(100),
    height: hp(69),
    position: "relative",
    top: hp(14),
    flexDirection: "column",
    justifyContent: "center",
  },
  mainContent: {
    // borderWidth: 2,
    flexDirection: "column",
    alignItems: "center",
    gap: hp(2),
    position:"relative",
    bottom:hp(1.5),
    height:hp(45)
  },
  
  toy8: {
    height: hp(14),
    width: wp(25),
  },
  text1: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: hp(4),
  },
  text2: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: hp(5.3),
  },
  text3: {
    color: "#fff",
    fontWeight:"200",
    fontSize: hp(2.5),
    textAlign: "center",
    width:wp(67),
    lineHeight:hp(3.7),

  },
});

export default Result;