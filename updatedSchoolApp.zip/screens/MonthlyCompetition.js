import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
  ImageBackground,
} from "react-native";
import RNPickerSelect from "react-native-picker-select";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

export const MonthlyCompetition = () => {
  const [selectedSubject, setSelectedSubject] = useState(null);

  return (
    <View style={styles.container}>
      <ImageBackground
        source={require("../assets/MonthlyCompetition.png")}
        imageStyle={{ borderRadius: 15 }}
        style={styles.mainImage2}
      >
        <View style={styles.firstCont}>
           <Image
                                source={require("../assets/images/coin.png")}
                                resizeMode="contain"
                                style={styles.upperImage}
                                // imageStyle={{ borderRadius: 8 }}
              
              
              />
              <Image
                                source={require("../assets/images/coin.png")}
                                resizeMode="contain"
                                style={styles.upperImage}
                                // imageStyle={{ borderRadius: 8 }}
              
              
              />

</View>

        <View style={styles.secondCont}>
          <Text style={styles.firstText}>After the being successful in the quiz after 5 Quins</Text>
        </View>
      </ImageBackground>

      <View style={styles.labelInputContainer}>
        <Text style={styles.label}>Upcoming Quiz</Text>
        <View style={styles.inputDiv1}>
          <TextInput style={styles.input} placeholder="Upcoming Quiz" />
        </View>
      </View>

      <View style={styles.labelInputContainer}>
        <Text style={styles.label}>Enroll Now</Text>

        <View style={styles.inputDiv2}>
          <TextInput style={styles.input} placeholder="Enroll Now" />
        </View>
      </View>

      <View style={styles.dropdownContainer}>
        <Text style={styles.label1}>List of Topic</Text>

        <RNPickerSelect
          onValueChange={(value) => setSelectedSubject(value)}
          items={[
            { label: "Mathematics", value: "mathematics" },
            { label: "Science", value: "science" },
          ]}
          placeholder={{ label: "Enroll Now", value: null }}
          value={selectedSubject}
          style={{
            inputIOS: styles.dropdownInput,
            inputAndroid: styles.dropdownInput,
            // borderWidth:2
          }}
        />
      </View>

      <TouchableOpacity onPress={() => navigation.navigate("HomeScreen")}>
        <View style={styles.editProfileBox}>
          <Text style={styles.editProfile}>SART THE QUIZ</Text>
        </View>
      </TouchableOpacity>
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    height: hp(100),
    // borderWidth: 2,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  input: {
    height: 40,
    borderColor: "#3C3C3C",
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
    width: "80%",
    borderRadius: 20,
    position: "fixed",
    // position:"absolute",
  },
  labelInputContainer: {
    marginBottom: 10,
    width: "122%",
    paddingLeft: "20%",
    top: "-1%",
    marginTop: hp(2),
  },
  label: {
    fontSize: 16,
    marginBottom: 10,
    // borderWidth: 2,
    fontWeight: "bold",
    color: "#595959",
  },
  label1: {
    fontSize: 16,
    marginTop: hp(8),
    // borderWidth: 2,
    fontWeight: "bold",
    color: "#595959",
  },
  mainImage2: {
    flexDirection:"column",
    justifyContent:"center",
    alignItems:"center",
    // borderWidth: 2,
    height: hp(41),
    width: "100%",
    // resizeMode:"cover"
    // top: "-8%"
  },
  dropdownInput: {
    marginTop: hp(4),
    height: hp(6),
    borderWidth: 2,
    borderColor: "#3C3C3C",
    // borderWidth: 2,
    marginBottom: hp(1),
    width: "80%",
    borderRadius: 30, // Add background color to avoid transparency
  },
  dropdownContainer: {
    // marginBottom: 10,
    width: "122%",
    paddingLeft: "20%",
    top: "-8%",
  },

  editProfileBox: {
    // Border color for the box
    borderWidth: 1, // Border width for the box
    borderRadius: 5, // Border radius for the box
    padding: hp(1), // Padding for the box content // Adjust the marginTop as needed
    backgroundColor: "#19245D",
    width: wp(80),
    height: hp(7),
    borderRadius: 30,
    top: "-50%",
  },

  editProfile: {
    top: "-5%",
    color: "white", // Set your desired color for the clickable text
    textAlign: "center",
    justifyContent: "center",
    alignItems: "center",
    marginTop: hp(1.3),
    fontSize: wp(5),
  },
  inputDiv1: {
    position: "relative",
  },
  secondCont:{
    // borderWidth:2,
    marginTop:hp(2)
  },
  firstText:{
   color:"#fff",
   fontWeight:"bold",
   fontSize:wp(7),
   textAlign:"center"



  },
  firstCont:{
   display:"flex",
   flexDirection:"row",
   gap:220,
//    borderWidth:2,
   borderColor:"yellow",
   marginBottom:hp(3)

  }
});