import React, { useState, useEffect } from "react";
// import { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  Dimensions,
  TouchableOpacity,
  ImageBackground,
} from "react-native";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";


const data = [
  {
    id: 1,
    time: "19:00 to 20:00",
    subject1: { imageSource: require("../assets/images/rectangle10.png") },
  },
  {
    id: 2,
    subTitle: "Mathematice",
    subject1: { imageSource: require("../assets/images/rectangle11.png") },
  },
  {
    id: 3,
    subTitle: "English",
    subject1: { imageSource: require("../assets/images/rectangle12.png") },
  },
  {
    id: 4,
    time: "17:00 to 18:00",
    subject1: { imageSource: require("../assets/images/rectangle10.png") },
  },
  {
    id: 5,
    subTitle: "Chemistry",
    subject1: { imageSource: require("../assets/images/rectangle13.png") },
  },
  {
    id: 6,
    subTitle: "Biology",
    subject1: { imageSource: require("../assets/images/rectangle14.png") },
  },
  {
    id: 7,
    time: "15:00 to 16:00",
    subject1: { imageSource: require("../assets/images/rectangle10.png") },
  },
  {
    id: 8,
    subTitle: "Information Technology",
    subject1: { imageSource: require("../assets/images/rectangle14.png") },
  },
  {
    id: 9,
    subTitle: "Calculas",
    subject1: { source: require("../assets/images/rectangle16.png") },
  },
  {
    id: 10,
    time: "19:00 to 20:00",
    subject1: { source: require("../assets/images/rectangle10.png") },
  },
  {
    id: 11,
    subTitle: "Mathematic",
    subject1: { source: require("../assets/images/rectangle11.png") },
  },
  {
    id: 12,
    subTitle: "English",
    subject1: { source: require("../assets/images/rectangle12.png") },
  },
  {
    id: 13,
    time: "17:00 to 18:00",
    subject1: { source: require("../assets/images/rectangle10.png") },
  },
  {
    id: 14,
    subTitle: "Chemistry",
    subject1: { source: require("../assets/images/rectangle13.png") },
  },
  {
    id: 15,
    subTitle: "Biology",
    subject1: { source: require("../assets/images/rectangle14.png") },
  },
];

// const CardComponent = ({ id, time, subTitle, subjectImage }) => (
//   <View style={styles.cardFirst}>
//     <TouchableOpacity>
//       {subjectImage && (
//         <ImageBackground
//           source={subjectImage}
//           imageStyle={{ borderRadius: 14 }}
//           style={styles.cardMy1}
//         >
//           {time && <Text style={styles.heading12}>{time}</Text>}
//         </ImageBackground>
//       )}
//     </TouchableOpacity>

//     <TouchableOpacity>
//       {subjectImage && (
//         <ImageBackground
//           source={subjectImage}
//           imageStyle={{ borderRadius: 14 }}
//           style={styles.cardMy}
//           resizeMethod="contain"
//         >
//           {subTitle && <Text style={styles.heading13}>{subTitle}</Text>}
//         </ImageBackground>
//       )}
//     </TouchableOpacity>

//     <TouchableOpacity>
//       {subjectImage && (
//         <ImageBackground
//           source={subjectImage}
//           imageStyle={{ borderRadius: 14 }}
//           style={styles.cardMy}
//           resizeMethod="contain"
//         >
//           {/* Use the id for the third card */}
//           {id && <Text style={styles.heading13}>{id}</Text>}
//         </ImageBackground>
//       )}
//     </TouchableOpacity>
//   </View>
// );

// const [currentDate,setCurrentDate]= useState("");
// useEffect(()=>{
// var date=new Date().getDate
// var month=new Date().getMonth +1
// var day=new Date().getDay

// setCurrentDate(
// date + "/" + month + "/" +day

// )

// },[])

const TimeTable = () => {
  return (
    <View style={styles.container}>
      {/* <View style={styles.dateContainer}>
    <Text style={styles.date}>{ moment().calendar()}</Text> 
    </View> */}

      <View style={styles.firstContainer}>
        <Image
          source={require("../assets/images/coin.png")}
          resizeMode="cover"
          style={styles.image1}
        />
      </View>

      <View style={styles.secondContainer}>
        <TouchableOpacity style={styles.secondButton}>
          <Text style={styles.buttonText}>
            {" "}
            <Text style={styles.buttonInnerText}>Monday</Text> 2.Feb
          </Text>
          <Text style={styles.buttonText}>
            {" "}
            <Text style={styles.buttonInnerText}>Tues</Text> 3.Feb
          </Text>
          <Text style={styles.buttonText}>
            {" "}
            <Text style={styles.buttonInnerText}>Wed</Text> 4.Feb
          </Text>
        </TouchableOpacity>
      </View>

      {/* <View style={styles.cardContainer}>
    {data.map((card, index) => (
      <View key={card.id} style={styles.rowContainer}>
        <CardComponent
          id={card.id}
          time={card.time}
          subTitle={card.subTitle}
          subjectImage={card.subject1.imageSource}
        />
        <CardComponent
          id={data[index + 1]?.id}
          time={data[index + 1]?.time}
          subTitle={data[index + 1]?.subTitle}
          subjectImage={data[index + 1]?.subject2?.imageSource}
        />
        <CardComponent
          id={data[index + 2]?.id}
          time={data[index + 2]?.time}
          subTitle={data[index + 2]?.subTitle}
          subjectImage={data[index + 2]?.subject2?.imageSource}
        />
      </View>
    ))}


  </View> */}

      <View style={styles.cardContainer}>
        <View style={styles.cardFirst}>
          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle10.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy1}
            >
              <Text style={styles.heading12}>19:00 to 20:00</Text>
            </ImageBackground>
          </TouchableOpacity>

          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle11.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy}
              resizeMethod="contain"
            >
              <Text style={styles.heading13}>Mathematic</Text>
            </ImageBackground>
          </TouchableOpacity>

          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle12.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy}
            >
              <Text style={styles.heading13}>English</Text>
            </ImageBackground>
          </TouchableOpacity>
        </View>

        <View style={styles.cardFirst}>
          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle10.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy1}
            >
              <Text style={styles.heading12}>17:00 to 18:00</Text>
            </ImageBackground>
          </TouchableOpacity>

          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle13.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy}
              resizeMethod="contain"
            >
              <Text style={styles.heading13}>Chemistry</Text>
            </ImageBackground>
          </TouchableOpacity>

          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle14.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy}
            >
              <Text style={styles.heading13}>English</Text>
            </ImageBackground>
          </TouchableOpacity>
        </View>

        <View style={styles.cardFirst}>
          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle10.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy1}
            >
              <Text style={styles.heading12}>15:00 to 16:00</Text>
            </ImageBackground>
          </TouchableOpacity>

          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle15.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy}
              resizeMethod="contain"
            >
              <Text style={styles.heading13}>Information Technology</Text>
            </ImageBackground>
          </TouchableOpacity>

          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle16.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy}
            >
              <Text style={styles.heading13}>Calculas</Text>
            </ImageBackground>
          </TouchableOpacity>
        </View>

        <View style={styles.cardFirst}>
          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle10.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy1}
            >
              <Text style={styles.heading12}>19:00 to 20:00</Text>
            </ImageBackground>
          </TouchableOpacity>

          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle11.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy}
              resizeMethod="contain"
            >
              <Text style={styles.heading13}>Mathematic</Text>
            </ImageBackground>
          </TouchableOpacity>

          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle12.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy}
            >
              <Text style={styles.heading13}>English</Text>
            </ImageBackground>
          </TouchableOpacity>
        </View>

        <View style={styles.cardFirst}>
          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle10.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy1}
            >
              <Text style={styles.heading12}>17:00 to 18:00</Text>
            </ImageBackground>
          </TouchableOpacity>

          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle13.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy}
              resizeMethod="contain"
            >
              <Text style={styles.heading13}>Chemistry</Text>
            </ImageBackground>
          </TouchableOpacity>

          <TouchableOpacity>
            <ImageBackground
              source={require("../assets/images/rectangle14.png")}
              imageStyle={{ borderRadius: 14 }}
              style={styles.cardMy}
            >
              <Text style={styles.heading13}>English</Text>
            </ImageBackground>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.lastBtnContainer}>
        <TouchableOpacity>
          <ImageBackground
            source={require("../assets/images/rectangle17.png")}
            imageStyle={{ borderRadius: 6 }}
            style={styles.cardMyLast}
            resizeMethod="contain"
          >
            <Text style={styles.heading14}>Get Started</Text>
          </ImageBackground>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column",
    justifyContent: "space-between",
    marginTop: hp(3),
    height: "100%",
    alignItems: "center",
  },
  firstContainer: {
    flexDirection: "row",
    justifyContent: "flex-end",
    width: "15%",
    position: "relative",
    left: "20%",
    top: "4%",
  },
  cardContainer: {
    marginBottom: hp(-4),
    width: "100%",
  },
  // image1:
  cardFirst: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    marginTop: hp(0),
    paddingBottom: hp(0),
  },
  fourSecondFour: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "47%",
    borderRadius: 10,
    resizeMode: "contain",
  },
  cardMy: {
    marginTop: hp(1),
    marginBottom: -2,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    width: wp(30),
    height: hp(9.5),
    borderRadius: 10,
    overflow: "hidden",

  },
  cardMyLast: {
    marginTop: hp(1.4),
    marginBottom: hp(-0.1),
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    width: wp(28),
    height: hp(5.2),
    overflow: "hidden",
  },
  heading14: {
    color: "#fff",
    fontSize: wp(4),
  },
  cardMy1: {
    marginTop: hp(1.4),
    marginBottom: -2,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    width: wp(30),
    height: hp(9.5),
    borderRadius: 10,
    overflow: "hidden",
  },
  heading12: {
    fontSize: 15,
    color: "#000",
    fontWeight: "700",
    marginBottom: 5,
  },
  heading13: {
    fontSize: wp(3.9),
    color: "#fff",
    fontWeight: "600",
    marginBottom: 5,
  },
  secondContainer: {
    width: "95%",
  },
  secondButton: {
    flexDirection: "row",
    justifyContent: "space-around",
    backgroundColor: "#19245D",
    borderRadius: 20,
    paddingVertical: hp(1.9),
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: wp(4.4),
  },
  buttonInnerText: {
    color: "#fff",
    fontWeight: "200",
    fontSize: wp(4.1),
    marginRight: 4,
  },
  lastBtnContainer: {
    marginBottom: hp(3),
    top: "-5%"
  },
});

export default TimeTable;