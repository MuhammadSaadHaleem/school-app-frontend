import React from 'react';
import { View, Text, StyleSheet, ImageBackground, Dimensions, Image, TouchableOpacity } from 'react-native';
import { Searchbar, Card } from 'react-native-paper';
import { LinearGradient } from 'expo-linear-gradient';

const { width, height } = Dimensions.get('window');
const imagePath = '../assets/Rectangle 266.png';
const mathImage = require('../assets/Saly-42.png');
const playIcon = require('../assets/Group 2135.png')
import IoniconsIcon from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';




export const QuestionSolving = () => {
    const [searchQuery, setSearchQuery] = React.useState('');

    const navigation = useNavigation();
    const handleBack = () => {
        navigation.goBack()
    }

    React.useLayoutEffect(() => {
        navigation.setOptions({
            headerShown: false,
        });
    }, [navigation]);

    return (
        <View style={styles.container}>
            <TouchableOpacity onPress={handleBack}>
                <IoniconsIcon name="arrow-back" size={30} color="#000000" style={styles.backIcon} />
            </TouchableOpacity>
            <Text style={styles.text1}>Find your favorite syllabus Learning </Text>
            <Searchbar
                placeholder="Search for syllabus"
                onChangeText={setSearchQuery}
                value={searchQuery}
                style={styles.searchbar}
                inputStyle={styles.searchbarInput}

            />

            <Card style={styles.card}>
                <ImageBackground
                    source={require(imagePath)}
                    style={styles.cardImage}
                >
                    <View style={styles.overlay}>
                        <Text style={styles.cardContent}>What do you want to learn today?</Text>
                    </View>
                </ImageBackground>
            </Card>

            <TouchableOpacity style={styles.cardGradient} onPress={() => navigation.navigate('SelectQuiz')}>

                <LinearGradient
                    colors={['#FECAC5', '#FFC785']}
                    style={styles.cardGradient}
                >
                    <View style={styles.gradientContent}>
                        <Image source={mathImage} style={styles.icon} />

                        <Text style={styles.gradientText}>Mathematic Subject</Text>
                        <Image source={playIcon} style={styles.icon2} resizeMode="contain" />

                    </View>
                </LinearGradient>

            </TouchableOpacity>

            <TouchableOpacity style={styles.cardGradient} onPress={() => navigation.navigate('SelectQuiz')}>

                <LinearGradient
                    colors={['#0EA2DF', '#72D8FE']}
                    style={styles.cardGradient}
                >
                    <View style={styles.gradientContent}>
                        <Image source={mathImage} style={styles.icon1} />

                        <Text style={styles.gradientText}>English Subject</Text>

                        <Image source={playIcon} style={styles.icon21} resizeMode="contain" />

                    </View>
                </LinearGradient>
            </TouchableOpacity>

            <LinearGradient
                colors={['#CDBEFF', '#7A68FF']}
                style={styles.cardGradient1}
            >
                <View style={styles.gradientContent}>
                    <Image source={mathImage} style={styles.icon} />

                    <Text style={styles.gradientText}>Progress Tracker</Text>

                    <Image source={playIcon} style={styles.icon2} resizeMode="contain" />



                </View>
            </LinearGradient>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    text1: {
        fontSize: 30,
        color: 'black',
        width: '80%',
        marginTop: height * 0.15,
        textAlign: 'center',
        fontWeight: "bold",
        marginLeft: "-34%",
        width: "60%"
    },
    searchbar: {
        marginTop: height * 0.02,
        width: '90%',
        borderRadius: 20,
        backgroundColor: 'white',

    },
    searchbarInput: {
        fontSize: 16,
        color: 'black',
    },
    card: {
        marginTop: height * 0.04,
        marginBottom: height * 0.04,
        width: '90%',
        height: height * 0.25,
        borderRadius: 20,
        overflow: 'hidden',
    },
    cardContent: {
        fontSize: 18,
        color: 'white',
        textAlign: 'center',
    },
    cardImage: {
        flex: 1,
        width: '100%',
        height: '100%',
        resizeMode: 'cover',
    },
    overlay: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    cardGradient: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: height * 0.01,
        marginBottom: height * 0.005,
        width: '90%',
        height: height * 0.1,
        borderRadius: 15,
        overflow: 'hidden',
    },
    cardGradient1: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: height * 0.01,
        marginBottom: height * 0.05,
        width: '90%',
        height: height * 0.1,
        borderRadius: 15,
        overflow: 'hidden',
    },

    gradientContent: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        marginRight: "10%"
    },

    gradientText: {
        fontSize: 20,
        color: 'white',
        textAlign: 'center',
        fontWeight: 'bold',
    },
    icon: {
        width: 30,
        height: 40,
        marginRight: 8,
    },

    icon1: {
        width: 30,
        height: 40,
        marginRight: 8,
    },


    icon2: {
        width: 30,
        height: 30,
        marginLeft: 60
    },
    icon21: {
        width: 30,
        height: 30,
        marginLeft: 90,
        marginRight: -8
    },
    backIcon: {
        right: "40%",
        top: 110,
        marginBottom:20
    }
});

export default QuestionSolving;
