import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Image } from 'react-native';
import { QuestionSolving } from './QuestionSolving';

import { Settings } from './Settings';

const Tab = createBottomTabNavigator();

import homeIcon from '../assets/Group 2138.png';
import questionIcon from '../assets/Group 2139.png';
import helpIcon from '../assets/Group 2140.png';
import settingsIcon from '../assets/Group 2142.png';
import Help from './Help';
import ProfileEdit from './ProfileEdit';
import { Homefinal } from './Homefinal';
import { TypeYourQuestion } from './TypeYourQuestion';

export const HomeScreenMain = () => {
    return (
        <Tab.Navigator
            tabBarOptions={{
                activeTintColor: 'lightgrey',
                inactiveTintColor: 'white',
                tabStyle: { height: 70 },
            }}
            screenOptions={({ route }) => ({
                tabBarIcon: ({ color, size }) => {
                    let iconSource;
                    let iconSize = 40; // Adjust the size as per your requirement

                    if (route.name === 'HomeFinal') {
                        iconSource = homeIcon;
                    }
                    else if (route.name === 'QuestionSolving') {
                        iconSource = questionIcon;
                    } else if (route.name === 'TypeYourQuestion') {
                        iconSource = helpIcon;
                    } else if (route.name === 'ProfileEdit') {
                        iconSource = settingsIcon;
                    }

                    return <Image source={iconSource} style={{ width: iconSize, height: iconSize, tintColor: color }} />;
                },
                tabBarLabel: '', // Set an empty string for the label
            })}
        >

            <Tab.Screen
                name="HomeFinal"
                component={Homefinal}
                options={{ tabBarStyle: { backgroundColor: '#19245D' } }}
            />

            <Tab.Screen
                name="QuestionSolving"
                component={QuestionSolving}
                options={{ tabBarStyle: { backgroundColor: '#19245D' } }}
            />
            <Tab.Screen
                name="TypeYourQuestion"
                component={TypeYourQuestion}
                options={{ tabBarStyle: { backgroundColor: '#19245D' } }}
            />
            <Tab.Screen
                name="ProfileEdit"
                component={ProfileEdit}
                options={{ tabBarStyle: { backgroundColor: '#19245D' } }}
            />
        </Tab.Navigator>
    );
};
