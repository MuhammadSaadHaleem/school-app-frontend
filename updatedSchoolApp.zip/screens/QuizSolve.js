import { useNavigation } from '@react-navigation/native';
import React from 'react'
import { View, Text, StyleSheet, Image, Dimensions, TouchableOpacity, ImageBackground } from 'react-native';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';

const QuizSolve = () => {


    const navigate = useNavigation()
    const handleBack = () => {
        navigate.goBack()
    }
    return (

        <View style={styles.container}>

            <View style={styles.image}>
                <ImageBackground
                    source={require('../assets/QuizSolve.png')}
                    style={styles.card}
                    resizeMode='contain'
                />
                <View style={styles.backButton}>
                    <TouchableOpacity onPress={handleBack}>
                        <IoniconsIcon name="arrow-back" size={30} color="white" style={styles.backIcon} />
                    </TouchableOpacity>
                </View>

            </View>

            <View style={styles.image1}>
                <Image
                    source={require('../assets/ResultBox.png')}
                    style={styles.card1}
                    resizeMode='contain'
                />
            </View>

            <View style={styles.mainText}>
                <Text style={styles.mainText1}>
                    Results of Fantasy Quiz #156
                </Text>
            </View>

            <View style={styles.middleText}>

                <View style={[styles.middleItem, styles.inline]}>
                    <Image source={require("../assets/ScoreGained.png")} style={styles.icon} resizeMode='contain' />
                    <Text style={styles.inlineText}>SCORE GAINED                      120</Text>
                </View>

                <View style={[styles.middleItem, styles.inline]}>
                    <Image source={require("../assets/check.png")} style={styles.icon} resizeMode='contain' />
                    <Text style={styles.inlineText}>CORRECT PREDICTIONS      10</Text>
                </View>

            </View>


            <View style={styles.result}>
                <TouchableOpacity onPress={() => navigate.navigate("Result")}>
                    <View style={styles.editProfileBox}>
                        <Text style={styles.editProfile}>Result</Text>
                    </View>
                </TouchableOpacity>
            </View>

        </View>

    )
}

export default QuizSolve

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',

    },

    card: {
        width: '100%',
        height: "100%",
        overflow: 'hidden',
    },

    card1: {
        width: '100%',
        height: "100%",
        overflow: 'hidden',

    },
    image: {
        width: '100%',
        height: "35%",
        top: "-1%",
        position: "absolute"
    },
    image1: {
        width: '40%',
        height: "19%",
        top: "32%",
        position: "absolute",
    },

    backButton: {
        position: "absolute",
        top: "30%",
        left: "7%",
    },
    backIcon: {
        left: "5%",
    },
    mainText: {
        top: "15%",
        // borderWidth:2,

    },
    mainText1: {

        fontSize: 24,
        fontWeight: "bold",
        color: "#191D63"
    },

    middleContainer: {
        flexDirection: 'row', // Arrange views horizontally
        justifyContent: 'space-around', // Evenly distribute views horizontally
        marginTop: 20,
    },

    middleText: {
        top: "21%"
    },
    middleItem: {
        alignItems: 'center', // Center items horizontally
    },
    inline: {
        flexDirection: 'row', // Display items inline
        alignItems: 'center', // Align items vertically
    },
    icon: {
        width: 20,
        height: 20,
        marginBottom:40,
    },
    inlineText: {
        fontSize: 20,
        fontWeight:"bold",
        marginBottom:40,
        marginLeft: 25, // Add some space between the icon and text
    },


    editProfileBox: {
        // Border color for the box
        borderWidth: 1, // Border width for the box
        borderRadius: 5, // Border radius for the box
        padding: 4, // Padding for the box content // Adjust the marginTop as needed
        backgroundColor: "#19245D",
        width: 320,
        height: 50,
        borderRadius: 30,
    },

    editProfile: {
        top: '-5%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 10,
        fontSize: 18
    },
    result: {
        top: "28%",

    }


})