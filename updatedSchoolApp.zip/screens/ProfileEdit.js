import React from 'react';
import { View, Text, StyleSheet, Dimensions, TouchableOpacity } from 'react-native';
import { IconButton, Card } from 'react-native-paper';
import { LinearGradient } from 'expo-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { useNavigation } from '@react-navigation/native';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
  } from "react-native-responsive-screen";



const { height } = Dimensions.get('window');

export const ProfileEdit = () => {

    React.useLayoutEffect(() => {
        navigation.setOptions({
            headerShown: false,
        });
    }, [navigation]);

    const navigation = useNavigation();
    const handleBack = () => {
        navigation.goBack()
    }

    const menuItems = [
        { text: 'Edit Profile', icon: 'user' },
        { text: 'Change Password', icon: 'lock' },
        { text: 'Security', icon: 'shield' },
        { text: 'Subscription Plan', icon: 'credit-card' },
        { text: 'About', icon: 'info-circle' },
        { text: 'FAQ', icon: 'question-circle' },
        { text: 'Logout', icon: 'sign-out' }
    ];


    const handleMenuItemPress = (text) => {
        // Handle onPress action for each menu item
        if (text === 'Subscription Plan') {
            // Navigate to the SubscriptionPlan screen
            navigation.navigate('SubscriptionPlan');
        }
        else if (text === 'Edit Profile') {
            navigation.navigate("EditProfile")
        }
        else if(text==='About'){
            navigation.navigate('About')
        }
        else if (text==="Security"){
            navigation.navigate("SubscriptionPlanUnpaid")
        }
        else if (text==="FAQ"){
            navigation.navigate("FAQ")
        }
        else if (text==="Logout"){
            navigation.navigate("SignIn")
        }
        // Add similar conditions for other menu items if needed
    };


    return (
        <View style={styles.container}>
            {/* <IconButton
                icon="menu" // Replace with the icon name you want for the side menu
                size={30}
                onPress={() => {
                    navigation.navigate('ProfileEdit'); // Replace 'YourScreenName' with the actual name of the screen you want to navigate to

                }}
                style={styles.icon}
            /> */}

            <View style={styles.cardContainer}>


                <LinearGradient
                    colors={['#72D8FE', '#2CB4EC']}
                    style={styles.cardGradient}
                />

                
                <View style={styles.circleBox}></View>
            </View>

            <View>
            <TouchableOpacity onPress={handleBack}>
                    <IoniconsIcon name="arrow-back" size={30} color="white" style={styles.backIcon} />
                </TouchableOpacity>
            </View>

            <View style={styles.profile}>
            <Text style={styles.name}>Profile </Text>
            <Text style={styles.email} >www.@gmail.com</Text>
            </View>

            <View>
            <TouchableOpacity onPress={{}} style={styles.btn1}>
                <View style={styles.editProfileBox}>
                    <Text style={styles.editProfile}>Edit Profile</Text>
                </View>
            </TouchableOpacity>
            </View>

            <View style={styles.menuContainer}>
                {menuItems.map((item, index) => (
                    <TouchableOpacity key={index} onPress={() => handleMenuItemPress(item.text)}>
                        <View style={styles.menuItem}>
                            <LinearGradient
                                colors={['#72D8FE', '#2CB4EC']}
                                style={styles.menuItemGradient}
                            >
                                <Icon name={item.icon} size={24} color="#fff" style={styles.icon} />
                            </LinearGradient>
                            <Text style={styles.menuText}>{item.text}</Text>
                        </View>
                    </TouchableOpacity>
                ))}
            </View>

        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    cardContainer: {
        position: 'absolute',
        top: hp(0),
        left: wp(0),
        right: wp(0),
        bottom: hp(0),
    },
    profile:{
        // borderWidth: 1,
        top:"5%",
        alignItems:"center"
        
    },
    name: {
        fontSize: wp(5),
        fontWeight: "bold",
        top: "2%",
    },
    email: {

    },
    editProfileBox: {
        borderWidth: 1,
        borderRadius: 5,
        padding: hp(1),
        backgroundColor: "#19245D",
        width: wp(50),
        height: hp(10),
        borderRadius: 30,
        top: "50%",
        marginBottom: hp(4), // Adjust the marginBottom to create separation from the menu items
        height: hp(6)
    },
    menuItemGradient: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: wp(3.1),
        paddingVertical: hp(0.8),
        borderRadius: 50,
        marginVertical: -4,
        marginRight: "30%",
        top: "70%",
    },

    editProfile: {
        top: '-1%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: hp(0.5),
        fontSize: wp(5)
    },
    cardGradient: {
        flex: 1,
        backgroundColor: 'transparent', // Set the background to transparent so that the gradient is visible
        position: 'absolute',
        top: hp(0),
        left: wp(0),
        right: wp(0),
        bottom: hp(0),
        borderRadius: 50,
        height: "36%",
        width: "100%",
        marginTop: "-15%",
    },
    circleBox: {
        width: wp(35),
        height: hp(17),
        borderRadius: 100,
        backgroundColor: 'white', // Set your color for the circular box
        position: 'absolute',
        top: '14%',
        left: '33%',
    },

    menuContainer: {
        marginTop: hp(-25),
        // borderWidth:2,
        height:hp(50),
        marginBottom:hp(4),
        marginRight:wp(18),
        top: "26%"

    },
    menuItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: wp(4),
        paddingVertical: hp(1.5),
        borderRadius: 50,
        marginVertical: hp(-0.2),
        marginRight: "30%",
        // borderWidth:2,
    },
    icon: {
        marginRight:wp(0.3),


    },
    menuText: {
        fontSize: wp(3.9),
        color: 'black',
        margin: hp(-2),
        marginTop: "14%",
        marginLeft: "-20%"
    },
    backIcon: {
        right: wp(40),
        top:hp(-15)
        
    },
    btn1:{
   marginTop:hp(0.7)

    }


});

export default ProfileEdit;