import React from 'react'
import { View, Text, Button, StyleSheet, Image, Pressable, TextInput, TouchableOpacity } from 'react-native';
import Icon from 'react-native-ico-material-design';
import { LinearGradient } from 'expo-linear-gradient';
import CheckBox from 'expo-checkbox';
import { useNavigation } from '@react-navigation/native';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
  } from "react-native-responsive-screen";


export const SignIn = () => {

    // const navigation = useNavigation()
    // const handleBack = () => {
    //     navigation.goBack()
    // }
    const navigation = useNavigation();
    const handleBack = () => {
        navigation.goBack()
    }

    const [isChecked, setChecked] = React.useState(false)
    return (
        <View style={styles.container}>


            {/* <View>
                <TouchableOpacity onPress={handleBack}>

                    <Text >SAad</Text>

                </TouchableOpacity>
            </View> */}

            <View style={styles.cardContainer}>
                
                <LinearGradient
                    colors={['#72D8FE', '#2CB4EC']}
                    style={styles.cardGradient}
                />


                <TouchableOpacity onPress={handleBack}>
                    <IoniconsIcon name="arrow-back" size={30} color="white" style={styles.backIcon} />
                </TouchableOpacity>
                
                <Image
                    style={styles.image}
                    source={require('../assets/Saly-10.png')}
                    resizeMode="contain"
                >
                </Image>
            </View>
           <View style={styles.mainDiv}>

            <View style={styles.signin}>

            <Text style={styles.signText}>SIGN IN</Text>
            </View>

            <TextInput
                style={styles.input}
                placeholder="Username"
            // Additional TextInput props as needed
            >

            </TextInput>

            <TextInput
                style={styles.input}
                placeholder="Password"
                secureTextEntry  // Use this if it's a password input
            // Additional TextInput props as needed
            />

            <View style={styles.checkboxContainer}>
                <CheckBox value={isChecked} onValueChange={() => setChecked(!isChecked)} />
                <Text style={styles.checkboxText}>Remember me</Text>
                <Text style={styles.forgotPasswordText}>Forgot Password?</Text>


            </View>

            <TouchableOpacity onPress={() => navigation.navigate("HomeScreen")}>
                <View style={styles.editProfileBox}>
                    <Text style={styles.editProfile}>SIGN IN</Text>
                </View>
            </TouchableOpacity>

            <View style={styles.creatAnAccount}>
                <Text style={styles.checkboxText} onPress={() => navigation.navigate('SignUp')}>Create an account</Text>
                <Text style={styles.forgotPasswordText}>Continue as a guest</Text>


            </View>

            <View style={styles.socialButtonsContainer}>
                {/* Google Sign In Button */}
                <TouchableOpacity style={styles.googleButton}>
                    <IoniconsIcon name="logo-google" size={20} color="white" />
                    <Text style={styles.socialButtonText}> Google</Text>
                </TouchableOpacity>

                {/* Facebook Sign In Button */}
                <TouchableOpacity style={styles.facebookButton}>
                    <IoniconsIcon name="logo-facebook" size={20} color="white" />
                    <Text style={styles.socialButtonText}> Facebook</Text>
                </TouchableOpacity>
            </View>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        // flex: 1,
        // justifyContent: 'center',
        // alignItems: 'center',
        height:hp(100)

    },
    cardContainer: {
        position: 'absolute',
        top: hp(0),
        left: wp(0),
        right: wp(0),
        bottom: hp(0),
    },

    cardGradient: {
        backgroundColor: 'transparent', // Set the background to transparent so that the gradient is visible
        position: "absolute",
        top: hp(0),
        left: wp(0),
        right: wp(0),
        bottom: hp(0),
        borderRadius: 50,
        height: hp(41.8),
        width: "100%",
        marginTop: hp(-7.6),
    },

    image: {

        width: wp(55),
        height: hp(52),
        // borderRadius: 100,
        // backgroundColor: 'white', // Set your color for the circular box
        position: 'relative',
        bottom: hp(3.8),
        left: wp(22),
        alignItems:"center"
        


    },

    signText: {
        fontSize: wp(7),
        fontWeight: "bold",
        color: "#030303",
        marginTop: "60%",
        marginBottom: hp(2.2)
    },

    input: {
        height: hp(6),
        borderColor: '#000000',
        borderWidth: 1,
        marginBottom: hp(1.8),
        paddingLeft: wp(4),
        fontWeight:"bold",
        // color:"#000",
        width: '80%',
        borderRadius: 30,

    },
    checkboxContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: hp(1),
    },

    checkboxText: {
        marginLeft: wp(3),
    },

    forgotPasswordText: {
        marginLeft: '22%',
        color: '#19245D',
    },

    creatAnAccount: {
        flexDirection: 'row',
        alignItems: 'center',
    },

    editProfileBox: {
        // Border color for the box
        borderWidth: 1, // Border width for the box
        borderRadius: 5, // Border radius for the box
        padding: 5, // Padding for the box content // Adjust the marginTop as needed
        backgroundColor: "#19245D",
        width: wp(80),
        height: hp(6),
        borderRadius: 30,
        top: hp(3),
        marginBottom: hp(6)
    },

    editProfile: {
        top: '-5%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: hp(1),
        fontSize: wp(4.4)
    },

    socialButtonsContainer: {
        flexDirection: 'row',
        marginTop: hp(2),

    },

    googleButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#141414', // Google Blue
        padding: 10,
        borderRadius: 5,
        marginRight: wp(4),
        width: "30%"
    },

    facebookButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#19245D', // Facebook Blue
        padding: wp(3),
        borderRadius: 5,
        width: "36%"
    },

    socialButtonText: {
        color: 'white',
        marginLeft: wp(2),
        fontSize: wp(4.5),
        fontWeight: "bold"
    },

    backIcon: {
        top: hp(10),
        left:wp(5),
        flexDirection:"row",
        justifyContent:"center",
        // borderWidth:2,
        width:wp(17)
    },
    mainDiv:{
//    borderWidth:2,
   flexDirection:"column",
   alignItems:"center",
   width:"100%",
   marginTop:hp(13),
//    position:"sticky",
//    bottom:hp(0.4)

//    top:hp(2)
//    height:hp(40)


    },

})