import React from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    TouchableOpacity,
    ImageBackground,

} from "react-native";
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from "react-native-responsive-screen";

const BrainPage2 = () => {
    return (
        <View style={styles.container}>
            
            <Image
                source={require("../assets/images/mask2.png")}
                resizeMode="contain"
                style={styles.upperImage}
                imageStyle={{ borderRadius: 8 }}
            />

            <View style={styles.fourDiv}>
                <View style={styles.fourSecond}>



                    <TouchableOpacity style={styles.fourSecondFirst}>



                        <ImageBackground
                            source={require("../assets/images/bg1.png")}
                            imageStyle={{ borderRadius: 14 }}
                            style={styles.fourSecondOne}
                        >

                            <Image
                                source={require("../assets/images/hand3.png")}
                                resizeMode="contain"
                                style={styles.upperImage}
                                imageStyle={{ borderRadius: 8 }}
                            />

                            <Text style={styles.heading3}>Essay writing</Text>
                        </ImageBackground>
                    </TouchableOpacity>


                    <TouchableOpacity>
                        <ImageBackground
                            source={require("../assets/images/bg5.png")}
                            imageStyle={{ borderRadius: 14 }}
                            style={styles.fourSecondOne}
                        >

                            <Image
                                source={require("../assets/images/robot2.png")}
                                resizeMode="contain"
                                style={styles.upperImage}
                                imageStyle={{ borderRadius: 8 }}
                            />

                            <Text style={styles.heading4}>Story Learning</Text>
                        </ImageBackground>
                    </TouchableOpacity>
                </View>

                <View style={styles.fourSecond}>
                    <TouchableOpacity>
                        <ImageBackground
                            source={require("../assets/images/bg6.png")}
                            imageStyle={{ borderRadius: 14 }}
                            style={styles.fourSecondOne}
                        >
                            <Image
                                source={require("../assets/images/robot4.png")}
                                resizeMode="contain"
                                style={styles.upperImage}
                                imageStyle={{ borderRadius: 8 }}
                            />

                            <Text style={styles.heading4}>Poem Learning</Text>
                        </ImageBackground>
                    </TouchableOpacity>


                    <TouchableOpacity>
                        <ImageBackground
                            source={require("../assets/images/bg7.png")}
                            imageStyle={{ borderRadius: 14 }}
                            style={styles.fourSecondOne}
                        >
                            <Image
                                source={require("../assets/images/toy18.png")}
                                resizeMode="cover"
                                style={styles.miniImage}
                            />

                            <Text style={styles.heading4}>Brainy Tool 4</Text>
                        </ImageBackground>
                    </TouchableOpacity>
                </View>

                <View style={styles.fourSecond}>
                    <TouchableOpacity>
                        <ImageBackground
                            source={require("../assets/images/bg8.png")}
                            imageStyle={{ borderRadius: 14 }}
                            style={styles.fourSecondOne}
                        >
                            <Image
                                source={require("../assets/images/toy18.png")}
                                resizeMode="contain"
                                style={styles.miniImage}
                            />
                            <Text style={styles.heading3}>Brainy Tool 5</Text>
                        </ImageBackground>
                    </TouchableOpacity>



                    <TouchableOpacity>
                        <ImageBackground
                            source={require("../assets/images/bg9.png")}
                            imageStyle={{ borderRadius: 14 }}
                            style={styles.fourSecondOne}
                        >
                            <Image
                                source={require("../assets/images/toy18.png")}
                                resizeMode="contain"
                                style={styles.miniImage}
                            />

                            <Text style={styles.heading4}>Brainy Tool 6</Text>
                        </ImageBackground>
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop: hp(2),
        alignItems: "center",
    },

    fourDiv: {
        width: "100%",
        marginBottom: hp(5),
        paddingHorizontal: wp(4),
        marginTop: hp(-1)
    },

    para: {
        color: "#B5B5B5",
        fontSize: wp(5.2),
        fontWeight: "200",
    },
    fourSecond: {
        flexDirection: "row",
        justifyContent: "center",
        gap: 9,
        width: "100%",
        height: hp(16),
        marginBottom: hp(1),
    },
    fourSecondOne: {
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        width: wp(44),
        height: hp(15),
        borderRadius: 10,
    },

    heading3: {
        fontSize: wp(5.2),
        color: "#fff",
        fontWeight: "700",
        marginBottom: hp(0.6),
    },
    heading4: {
        fontSize: wp(5.2),
        color: "#fff",
        fontWeight: "700",
        marginBottom: hp(0.5),
        textAlign: "center",
    },
    para: {
        color: "#FFFFFF",
        fontSize: wp(5.2),
        fontWeight: "200",
    },

    miniImage: {
        position: "relative",
        top: "10%"
    },
    upperImage: {
        marginRight: 1,
        width: "100%",
    },
});

export default BrainPage2;