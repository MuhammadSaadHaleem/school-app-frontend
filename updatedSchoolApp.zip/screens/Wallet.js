import React from 'react'
import { View, Text, StyleSheet, Image, Dimensions, TouchableOpacity, ImageBackground } from 'react-native';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from "react-native-responsive-screen";

const Wallet = () => {
    return (
        <View style={styles.container}>


            <View style={styles.mainDiv}>

            </View>


            <View style={styles.secondDiv}>

                <ImageBackground
                    source={require("../assets/images/BG.png")}
                    resizeMode="contain"
                    style={styles.secondDivBackground}
                >

                    <Image source={require("../assets/images/image.png")} style={styles.coin} resizeMode='contain' />

                    <TouchableOpacity style={styles.addButton}>

                        <Image source={require("../assets/images/button.png")} />
                    </TouchableOpacity>

                </ImageBackground>
            </View>

            <View style={styles.actions}>
                <Text style={styles.actionsText}>Actions</Text>
            </View>





            <View style={styles.topQuiz}>
                <Text style={styles.topQuizText}>Top Quiz</Text>
            </View>


        </View>
    )
}

export default Wallet

const styles = StyleSheet.create({
    container: {

    },

    mainDiv: {
        width: wp("100%"),
        height: hp("20%"),
        top: "6%",
        backgroundColor: "#19245D"
    },

    secondDiv: {
        width: wp("80%"),
        height: hp("20%"),
    },

    secondDivBackground: {
        alignItems: "center",
        justifyContent: "center",
        width: wp("90%"),
        height: hp("25%"),
        left: "7%",
        top: hp("8%")
    },

    coin: {
        left: "30%",
        height: hp("25%")
    },
    actions:{
        top:hp("17%")
    },

    actionsText:{
        fontSize:18,
        fontWeight:"bold",
        left:"7%"
    },

    topQuiz:{
        top:hp("35%")
    },

    topQuizText:{
        fontSize:18,
        fontWeight:"bold",
        left:"7%"
    },
    addButton:{
        left:"-30%",
        top:"-10%"
    }
})