import React from 'react';
import { View, Text, StyleSheet, Image, Dimensions, TouchableOpacity, ImageBackground } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { FontAwesome } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
  } from "react-native-responsive-screen";





const Help = () => {

    React.useLayoutEffect(() => {
        navigation.setOptions({
            headerShown: false,
        });
    }, [navigation]);

    const navigation = useNavigation();
    const handleBack = () => {
        navigation.goBack()
    }

    return (
        <View style={styles.container}>
            <LinearGradient colors={["#72D8FE", "#2CB4EC"]} style={styles.background}>

                <TouchableOpacity onPress={handleBack}>
                    <IoniconsIcon name="arrow-back" size={30} color="#000000" style={styles.backIcon} />
                </TouchableOpacity>

                <View style={styles.maindiv}>
                    <Text style={styles.maintext}>Need {'\n'}Help {'\n'}With? </Text>
                    <Image source={require('../assets/1 2.png')} resizeMode='cover' style={styles.image5} />
                </View>

                <View style={styles.secondDiv}>
                    <LinearGradient colors={["#72D8FE", "#AEE7FF"]} style={styles.secondDiv}>
                        <Text style={styles.heading}>Ask a Question</Text>
                        <View style={styles.thirdDiv}>
                            <TouchableOpacity style={styles.smallDiv} onPress={() => navigation.navigate('TypeYourQuestion')}>
                                <FontAwesome name="keyboard-o" size={20} color="white" />

                            </TouchableOpacity>
                            <TouchableOpacity style={styles.smallDiv} onPress={() => navigation.navigate('CameraScreen')}>
                                <FontAwesome name="camera" size={20} color="white" />

                            </TouchableOpacity>

                        </View>
                    </LinearGradient>

                </View>



            </LinearGradient>





            <ImageBackground
                source={require('../assets/Rectangle 266.png')} // Replace with the actual path to your image
                style={styles.backgroundImage}
                imageStyle={{ borderRadius: 14 }}
            >


                <View style={styles.innerDiv} >
                    <Text style={styles.heading2}> Get unlimited access today! </Text>


                    <View style={styles.paraDiv}>
                        <Text style={styles.para}>
                            upgrade your learning with unlimited {'\n'} access to premium per...
                        </Text>

                        <Image source={require('../assets/toy.png')} resizeMode='contain' style={styles.image6} />

                    </View>

                </View>


            </ImageBackground>



        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',

    },
    background: {
        width: '100%', // Set width to 100% of the screen
        alignItems: 'center',
        position: "relative",
        bottom: hp(9),
        height: hp(70)

    },
    backgroundImage: {
        resizeMode: 'cover',
        height: hp(20),
        width: '95%',
        borderRadius: 20,
        marginLeft: wp(5)


    },
    heading: {
        fontSize: wp(6.2),
        color: "#FFFFFF",
        fontWeight: "900"



    },
    heading2: {
        fontSize: wp(6),
        color: "#FFFFFF",
        fontWeight: "900"



    },


    maindiv: {
        flexDirection: 'row',
        height: hp(35),
        justifyContent: 'center',
        alignItems: 'center',
        // borderWidth: 2,
        width: '100%',
        marginTop: hp(11),
    },
    innerDiv: {
        flexDirection: 'column',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        // borderWidth: 2,
        width: '100%',
        marginTop: hp(2.5),
        padding: hp(2)

    },
    smallDiv: {
        height: hp(5),
        width: wp(30),
        backgroundColor: '#19245D',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5,
        marginRight: wp(5)
    },
    thirdDiv: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: hp(2.7),
        // alignItems:"center"

    },
    secondDiv: {
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        // borderWidth: 2,
        borderRadius: 25,
        // backgroundColor: '#AEE7FF',
        width: '100%',
        height: hp(21),
        marginTop: hp(2.6)
    },
    maintext: {
        fontSize: wp(8.4),
        fontWeight: 'bold',
        marginLeft: wp(10),
        color: '#19245D',
        marginTop: hp(6),
    },
    image5: {
        height: '100%',
        width: '65%',
        marginRight: wp(7.5),
        top: "8%"
    },
   
  
    paraDiv: {
        marginTop: hp(2),
        flexDirection: "column",
        width: "100%"

    },
    para: {
        color: "#FFFFFF",
        position:"relative",
        left:wp(1.6),
        fontSize: wp(4.2),
        fontWeight: "200",

    },
    image6: {
        position: "relative",
        left: wp(66),
        bottom:hp(4)

    },
    backIcon: {
        right: "40%",
        top: hp(15)
    }
});

export default Help;