import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react'
import { View, Text, StyleSheet, Image, Dimensions, TouchableOpacity, ImageBackground } from 'react-native';
import { Button, TextInput, Switch } from 'react-native-paper';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from "react-native-responsive-screen";


const PaymentMethod = () => {

    const navigation = useNavigation()

    const [isDefaultCard, setIsDefaultCard] = useState(false);
    const [saveForNextTime, setSaveForNextTime] = useState(false);
    return (
        <View style={styles.container}>

            <View style={styles.mainText} >
                <Text style={styles.firstText}>Add credit or debit card</Text>
                <Text style={styles.secondText}>Your payment details are stored securely.{"\n"}By adding a card, you won’t be charged yet.</Text>
            </View>



            <View style={styles.firstbutton}>
                <TouchableOpacity onPress={() => navigation.navigate("HomeScreen")}>
                    <View style={styles.editProfileBox1}>
                        <Text style={styles.editProfile1}>Scan my card</Text>
                    </View>
                </TouchableOpacity>
            </View>

            <View style={styles.cardName}>
                <Text style={styles.cardNameText} >Name on card</Text>
                <TextInput
                    style={styles.input}
                    placeholder="0000 0000 0000 0000"></TextInput>
            </View>
            <View style={styles.cardDetails}>
                <View style={styles.cardNameExpire}>
                    <Text style={styles.cardExpiryText}>Expire date</Text>
                    <TextInput
                        style={styles.inputExpire}
                        placeholder="MM / YYYY "></TextInput>
                </View>


                <View style={styles.cardNameCVV}>
                    <Text style={styles.cardCVVText}>CVV</Text>
                    <TextInput
                        style={styles.inputCVV}
                        placeholder="123"
                    >
                    </TextInput>
                </View>
            </View>


            <View style={styles.toggleButtonContainer}>
                <View style={styles.toggleButton}>
                    <Text style={styles.toggleButtonText}>Make this my default card  </Text>
                    <Switch
                        value={isDefaultCard}
                        onValueChange={() => setIsDefaultCard(!isDefaultCard)}
                        color="#27B062"
                    />
                </View>
                <View style={styles.toggleButton}>
                    <Text style={styles.toggleButtonText}>Save this card for next time</Text>
                    <Switch
                        value={saveForNextTime}
                        onValueChange={() => setSaveForNextTime(!saveForNextTime)}
                        color="#27B062"
                    />
                </View>
            </View>

            <View style={styles.mainButton}>
                <TouchableOpacity onPress={() => navigation.navigate("Wallet")}>
                    <View style={styles.editProfileBox}>
                        <Text style={styles.editProfile}>Continue</Text>
                    </View>
                </TouchableOpacity>
            </View>
        </View>
    )
}

export default PaymentMethod


const styles = StyleSheet.create({
    container: {


    },

    mainText: {
        top: hp("2%"),
        left: "5%"
    },
    firstText: {
        top: hp("10%"),
        fontSize: 24,
        fontWeight: "bold"
    },

    secondText: {
        top: hp("11%"),


    },

    firstbutton: {
        top: hp("15%"),
        alignItems: "center",
        justifyContent: "center",
        // borderWidth: 2,
        borderRadius: 30
    },

    cardName: {
        top: hp("20%"),
        left: "5%",
        width: wp("90%"),
    },
    cardNameExpire: {
        top: hp("20%"),
        left: "21%",
        width: wp("48%"),
    },
    cardNameCVV: {
        top: hp("20%"),
        left: "21%",
        width: wp("48%"),
    },

    cardNameText: {
        fontSize: 18,
        fontWeight: "bold",
        marginBottom: "5%",

    },
    cardExpiryText: {
        fontSize: 18,
        fontWeight: "bold",
        marginBottom: "5%",



    },
    cardCVVText: {
        fontSize: 18,
        fontWeight: "bold",
        marginBottom: "5%",

    },
    cardDetails: {
        flexDirection: "row",
        marginBottom: "25%",
    },

    input: {
        height: 40,
        borderColor: '#2153B4',
        borderWidth: 1,
        marginBottom: 10,
        paddingLeft: 10,
        width: '100%',
        backgroundColor: "transparent",
        marginBottom: "10%"

    },
    inputExpire: {
        height: 40,
        borderColor: '#2153B4',
        borderWidth: 1,
        marginBottom: 10,
        paddingLeft: 10,
        width: '90%',
        backgroundColor: "transparent",
        marginBottom: "10%"

    },
    inputCVV: {
        height: 40,
        borderColor: '#2153B4',
        borderWidth: 1,
        marginBottom: 10,
        paddingLeft: 10,
        width: '90%',
        backgroundColor: "transparent",
        marginBottom: "10%"

    },

    editProfileBox: {
        // Border color for the box
        borderWidth: 1, // Border width for the box
        borderRadius: 5, // Border radius for the box
        padding: 5, // Padding for the box content // Adjust the marginTop as needed
        backgroundColor: "#19245D",
        width: 320,
        height: 50,
        borderRadius: 30,
    },

    editProfile: {
        top: '-5%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 10,
        fontSize: 18
    },


    editProfileBox1: {
        // Border color for the box
        borderWidth: 1, // Border width for the box
        borderRadius: 5, // Border radius for the box
        padding: 5, // Padding for the box content // Adjust the marginTop as needed
        width: 320,
        height: 50,
        borderRadius: 30,
        top: 20,
        marginBottom: 40,
        borderColor: "#2153B4"
    },

    editProfile1: {
        top: '-5%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 10,
        fontSize: 18,
        color: "#2153B4",
        fontWeight: "bold"
    },

    mainButton: {
        top: hp("10%"),
        width: wp("100%"),
        alignItems: "center"
    },

    lastText: {
        left: "5%",
        top: wp("15%"),

    },

    lastText1: {
        fontSize: 20,
        fontWeight: "bold",
        marginBottom: "8%"
    },
    toggleButtonContainer: {
        marginTop: 20,
        marginLeft: '5%',
        top: hp("5%")
    },
    toggleButton: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10,
    },
    toggleButtonText: {
        marginRight: wp("28%"),
        fontSize: 18,
        fontWeight: "bold"
    },
})