import React from "react";
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    TouchableOpacity
} from "react-native";
import { FontAwesome } from "@expo/vector-icons";
import { useState } from "react";
import { useNavigation } from "@react-navigation/native";
import IoniconsIcon from 'react-native-vector-icons/Ionicons';



const btnData = [
    {
        id: 1,
        image: require("../assets/images/bg11.png"),
        btnOption: "A",
        btnText: "It is a long established",


    },
    {
        id: 2,
        image: require("../assets/images/bg12.png"),
        btnOption: "B",
        btnText: "It is a long established",


    },
    {
        id: 3,
        image: require("../assets/images/bg13.png"),
        btnOption: "C",
        btnText: "It is a long established",
    }

]

const BtnComponent = ({
    id,
    image,
    btnOption,
    btnText,
}) => (
    <TouchableOpacity style={styles.touchableMain}>
        <ImageBackground
            source={image}
            imageStyle={{ borderRadius: 14 }}
            style={styles.btnFirst}
            resizeMethod="contain"
        >



            <TouchableOpacity style={styles.innerBtn}>

                <View style={styles.circle1}>
                    <Text style={styles.innerText}>{btnOption}</Text>
                </View>


            </TouchableOpacity>

            <Text style={styles.innerText2}>
                {btnText}
            </Text>



        </ImageBackground>
    </TouchableOpacity>
);




const ShowQuiz = () => {
    const [quizNumber, setQuizNumber] = useState("15")
    const [time, setTime] = useState("30:00")

    const navigation = useNavigation()

    const handleBack = () => {
        navigation.goBack()
    }


    return (
        <View style={styles.container}>
            <ImageBackground
                source={require("../assets/images/rectangle19.png")}
                style={styles.topImg}
                imageStyle={{ borderTopLeftRadius: 21, borderTopRightRadius: 21 }}
            >

                <View style={styles.backButton}>
                    <TouchableOpacity onPress={handleBack}>
                        <IoniconsIcon name="arrow-back" size={30} color="white" style={styles.backIcon} />
                    </TouchableOpacity>
                </View>
                <View style={styles.coinContainer}>

                    <Image
                        source={require("../assets/images/coin.png")}
                        resizeMethod="contain"
                        style={styles.coinStyle}
                    />
                </View>

                <View style={styles.topTextCont}>
                    <Text style={styles.topText}>Show Quiz</Text>
                </View>
            </ImageBackground>

            <View style={styles.quizSection}>
                <View style={styles.topHeading}>
                    <Text style={styles.leftHeading}>Quiz No:{quizNumber}</Text>
                    <Text style={styles.rightHeading}>{time} Mins</Text>

                </View>
                <Image
                    source={require("../assets/images/line12.png")}
                    resizeMethod="contain"
                    style={styles.lineStyle}
                />


                <View style={styles.paraCont}>

                    <Text style={styles.para}>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </Text>

                </View>

                <View style={styles.btnCont}>
                    {btnData.map((dataItem) => (
                        <BtnComponent key={dataItem.id} {...dataItem} />
                    ))}
                </View>



            </View>

            <TouchableOpacity style={styles.lastBtn}>
                <Text style={styles.lastBtnText}>Submit</Text>


            </TouchableOpacity>


        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        // borderWidth: 2,
        flex: 1,
        // justifyContent: "center",
        alignItems: "center",
        height: hp(100),
        // width:"100%"
    },
    topImg: {
        marginTop: hp(0),
        height: hp(30),
        width: wp(100),
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        position: "relaive",
    },
    topTextCont: {
        //    borderWidth:2,
        paddingHorizontal: wp(4),
        paddingVertical: hp(4),
        marginTop: hp(11),
    },
    topText: {
        color: "#fff",
        fontSize: hp(4),
        fontWeight: "900",
    },
    coinContainer: {
        //   borderWidth:2,
        position: "absolute",
        right: wp(4),
        top: hp(5),
    },
    quizSection: {
        // flexDirection:"row",
        // borderWidth:2,
        marginTop: hp(4),
        flexDirection: "column"


    },
    lineStyle: {
        // paddingHorizontal:wp(4),
        width: wp(93),
        marginLeft: wp(2),
        marginTop: hp(1),

    },
    topHeading: {
        //  borderWidth:2,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        gap: wp(33),
        paddingHorizontal: wp(2)
    },

    leftHeading: {
        color: "#191D63",
        fontSize: hp(4),
        fontWeight: "bold"
        // alignItems:"center"


    },
    rightHeading: {
        color: "#747474",
        fontWeight: "400",
        fontSize: hp(2)


    },
    innerBtn: {
        //  paddingTop:hp(2),
        //  paddingBottom:hp(2),
        // borderWidth:2


    },
    paraCont: {
        // borderWidth:2,
        marginBottom: hp(3),
        // lineHeight:20,




    },
    para: {
        color: "#818181",
        textAlign: "left",
        paddingHorizontal: wp(3),
        marginTop: hp(3),
        fontSize: hp(2.5),
        lineHeight: hp(3.9),




    },
    btnCont: {
        // borderWidth:2,
        borderColor: "red",
        flexDirection: "column",


    },
    btnFirst: {
        marginTop: 10,
        marginBottom: -2,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
        paddingLeft: wp(5),
        // width: wp(20),
        height: hp(7.6),
        borderRadius: 8,
        overflow: "hidden",
        marginHorizontal: wp(2.1),
        paddingVertical: hp(2),
        marginBottom: hp(1),
        // marginLeft:20
        // borderWidth:3,
        // paddingBottom:hp(3),
    },
    circle1: {
        // borderWidth:2,
        borderColor: "yellow",
        width: wp(11),
        height: hp(5.4),
        position: "relative",
        // bottom:hp(3),
        backgroundColor: "#fff",
        borderRadius: hp(53),
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        // marginVertical:hp(12)

    },
    innerText: {
        fontWeight: "bold",
        color: "#19245D",
        fontSize: hp(2.5),


    },

    innerText2: {
        color: "#fff",
        fontWeight: "bold",
        marginLeft: wp(5),
        fontSize: hp(2.5),

    },
    lastBtn: {
        marginTop: hp(2),
        backgroundColor: "#19245D",
        width: wp(92),
        height: hp(6.2),
        borderRadius: hp(12),
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
    },
    lastBtnText: {
        color: "#fff",
        fontWeight: "bold",
        fontSize: hp(2.3),

    },
    backButton: {
        position: "absolute",
        top: "22%"
    },
    backIcon: {
        left: -160,

    },

});

export default ShowQuiz;