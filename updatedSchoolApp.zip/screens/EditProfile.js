import React from 'react'
import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import Icon from 'react-native-ico-material-design';
import { LinearGradient } from 'expo-linear-gradient';
import CheckBox from 'expo-checkbox';
import { useNavigation } from '@react-navigation/native';
import IoniconsIcon from 'react-native-vector-icons/Ionicons';


export const EditProfile = () => {



    const navigation = useNavigation();
    const handleBack = () => {
        navigation.goBack()
    }

    return (
        <View style={styles.container}>


            <View style={styles.mainInput}>
                <View style={styles.labelInputContainer}>
                    <Text style={styles.label}> Name</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="Enter Your Name"
                    // Additional TextInput props as needed
                    >


                    </TextInput>
                </View>

                <View style={styles.labelInputContainer}>
                    <Text style={styles.label}> Age</Text>

                    <TextInput
                        style={styles.input}
                        placeholder="Enter Your Age"
                    // Additional TextInput props as needed
                    >

                    </TextInput>
                </View>

                <View style={styles.labelInputContainer}>
                    <Text style={styles.label}> Class</Text>

                    <TextInput
                        style={styles.input}
                        placeholder="Enter Your Calss"
                    // Additional TextInput props as needed
                    >

                    </TextInput>
                </View>

                <View style={styles.labelInputContainer}>
                    <Text style={styles.label}> School</Text>

                    <TextInput
                        style={styles.input}
                        placeholder="Enter Your School "
                    // Additional TextInput props as needed
                    >

                    </TextInput>
                </View>

            </View>
            {/* 
            <View style={styles.labelInputContainer}>
                <Text style={styles.label}> Password</Text>

                <TextInput
                    style={styles.input}
                    placeholder="Password"
                    secureTextEntry  // Use this if it's a password input
                // Additional TextInput props as needed
                />
            </View> */}



            <View style={styles.submitButton}>
                <TouchableOpacity onPress={() => navigation.navigate("ProfileEdit")}>
                    <View style={styles.editProfileBox}>
                        <Text style={styles.editProfile}>Submit Details</Text>
                    </View>
                </TouchableOpacity>
            </View>



            <View style={styles.cardContainer}>
                <LinearGradient
                    colors={['#72D8FE', '#2CB4EC']}
                    style={styles.cardGradient}
                >
                    <Text style={styles.gradientText}>Personal information</Text>
                    <Text style={styles.gradientText1}>Fill your information below or register with your social account.</Text>

                    <View style={styles.backButton}>
                        <TouchableOpacity onPress={handleBack}>
                            <IoniconsIcon name="arrow-back" size={30} color="black" style={styles.backIcon} />
                        </TouchableOpacity>
                    </View>

                </LinearGradient>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',

    },

    cardContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
    },

    cardGradient: {
        flex: 1,
        backgroundColor: 'transparent',
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        borderRadius: 50,
        height: '40%',
        width: '100%',
        marginTop: '-15%',
        justifyContent: 'center', // Center the text vertically
        alignItems: 'center', // Center the text horizontally
    },

    gradientText: {
        color: 'white',
        fontSize: 30,
        fontWeight: 'bold',
        marginTop: "30%",
        marginBottom: "5%"
    },

    gradientText1: {
        color: 'white',
        fontSize: 18,
        width: "70%",
        textAlign: "center"
    },

    mainInput: {
        top: "15%",
        width: "80%"
    },

    input: {
        height: 40,
        borderColor: '#3C3C3C',
        borderWidth: 1,
        marginBottom: 5,
        paddingLeft: 10,
        width: '100%',
        borderRadius: 20,

    },

    labelInputContainer: {
        marginBottom: 10,
        width: '100%',


    },

    label: {
        fontSize: 16,
        marginBottom: 10,
        fontWeight: "bold",
        color: "#595959"
    },

    submitButton: {
        top: "17%",
        alignItems: "center",
        justifyContent: "center"

    },

    editProfileBox: {
        // Border color for the box
        borderWidth: 1, // Border width for the box
        borderRadius: 5, // Border radius for the box
        padding: 5, // Padding for the box content // Adjust the marginTop as needed
        backgroundColor: "#19245D",
        width: 320,
        height: 50,
        borderRadius: 30,
    },

    editProfile: {
        top: '-5%',
        color: 'white', // Set your desired color for the clickable text
        textAlign: "center",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 10,
        fontSize: 18
    },
    // backIcon: {
    //     right: "80%",
    //     top: 1000
    // },
    backButton: {
        position: "absolute",
        top: "11%"
    },
    backIcon: {
        left: -160,
    

    },
});
