import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

const Card = ({ title, description, image }) => {
    return (
        <View style={styles.card}>
            {image && <Image source={image} style={styles.image} resizeMode="cover" />}
            <Text style={styles.title}>{title}</Text>
            <Text style={styles.description}>{description}</Text>

        </View>
    );
};

const styles = StyleSheet.create({
    card: {
        backgroundColor: '#fff',
        borderRadius: 39,
        padding: "8%", // Responsive padding
        margin: "2%", // Responsive margin
        width: "100%",
        height: "50%",
        alignItems: "center", // Center content horizontally
        justifyContent: "center", // Center content vertically
        marginTop: "45%"
    },
    title: {
        fontSize: 30, // Responsive font size based on viewport width
        fontWeight: 'bold',
        marginBottom: "8%", // Responsive margin
        color: "#161F32",
        marginTop: "2%",
        width: "80%",
    },
    description: {
        fontSize: 15, // Responsive font size based on viewport width
        color: '#555',
        textAlign: "center",
        width: "80%", // Responsive width
    },
    image: {
        marginTop: "-50%", // Responsive margin
    },
});

export default Card;
