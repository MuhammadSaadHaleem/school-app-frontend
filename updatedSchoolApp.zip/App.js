
import { View, Text, Button, StyleSheet, Image, TouchableOpacity, ImageBackground, Dimensions } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { LinearGradient } from "expo-linear-gradient";


import Card from './components/Card';
import { HomeScreenMain } from './screens/HomeScreen';
import { Tabs } from './navigations/Tabs';
import { ProfileEdit } from './screens/ProfileEdit';
import { SubscriptionPlan } from './screens/SubscriptionPlan';
import { SignIn } from './screens/SignIn';
import { SignUp } from './screens/SignUp';
import { EditProfile } from './screens/EditProfile';
import SelectQuiz from './screens/SelectQuiz';
import { Quiz } from './screens/Quiz';
import { MonthlyCompetition } from './screens/MonthlyCompetition';
import { CameraScreen } from './screens/CameraScreen';
import { ReTakeScreen } from './screens/ReTakeScreen';
import { Homefinal } from './screens/Homefinal';
import { TypeYourQuestion } from './screens/TypeYourQuestion';
import Start1 from './screens/start1';
import Start2 from './screens/Start2';
import Start3 from './screens/Start3';
import About from './screens/About';
import Learning from './screens/Learning';
import SubscriptionPlanUnpaid from './screens/SubscriptionPlanUnpaid';
import FAQ from './screens/FAQ';
import QuestionAndAnswer from './screens/QuestionAndAnswer';
import QuizRightAnswer from './screens/QuizRightAnswer';
import QuizSolve from './screens/QuizSolve';
import Help from './screens/Help';
import BrainPage2 from './screens/BrainPage2';
import ParentalReports from './screens/ParentalReports';
import Result from './screens/Result';
import TimeTable from './screens/TimeTable';
import ShowQuiz from './screens/ShowQuiz';
import PaymentMethod from './screens/PaymentMethod';
import Wallet from './screens/Wallet';


function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>

      <LinearGradient colors={["#72D8FE", "#2CB4EC"]} style={styles.container}>
        <Image
          source={require('./assets/Saly-22.png')}
          style={styles.image}
          resizeMode="cover"
        />

        <Image
          source={require('./assets/Ellipse 199.png')}
          style={styles.image1}
          resizeMode="cover"
        />


        <Card image={require('./assets/Group 2105.png')} title="Discover The Best Online Course" description="The average company forecasts a growth   178% in revenues for their first year, 100% for second, and 71% for third." />

        <View style={styles.buttonWrapper}>
          <Button
            title="Next"
            onPress={() => navigation.navigate('Details')}
            style={styles.buttonContainer}
          />
        </View>


      </LinearGradient>

    </View>

  );
}

function DetailsScreen({ navigation }) {
  return (
    <View style={styles.container}>

      <LinearGradient colors={["#72D8FE", "#2CB4EC"]} style={styles.container}>

        <Image
          source={require('./assets/Saly-1.png')}
          style={styles.image2}
          resizeMode="cover"
        />

        <Image
          source={require('./assets/Ellipse 200.png')}
          style={styles.image21}
          resizeMode="cover"
        />


        <Card image={require('./assets/Group 2118.png')} title="get your questions solved" description="The average company forecasts a growth   178% in revenues for their first year, 100% for second, and 71% for third." />
        <View style={styles.buttonWrapper}>
          <Button
            title="Next"
            onPress={() => navigation.navigate('Screen3')}
            style={styles.buttonContainer}
          />
        </View>


      </LinearGradient>

    </View>
  );
}



function Screen3({ navigation }) {
  return (
    <View style={styles.container}>

      <LinearGradient colors={["#72D8FE", "#2CB4EC"]} style={styles.container}>

        <Image
          source={require('./assets/Saly-16.png')}
          style={styles.image3}
          resizeMode="cover"
        />

        <Image
          source={require('./assets/Ellipse 200.png')}
          style={styles.image31}
          resizeMode="cover"
        />


        <Card image={require('./assets/Group 2117.png')} title="get ready for your exams" description="The average company forecasts a growth   178% in revenues for their first year, 100% for second, and 71% for third." />
        <View style={styles.buttonWrapper}>
          <Button
            title="Next"
            onPress={() => navigation.navigate('SignIn')}
            style={styles.buttonContainer}

          />
        </View>


      </LinearGradient>

    </View>
  );
}

const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>

      <Stack.Navigator initialRouteName="Home" screenOptions={{ headerShown: false }}>
        {/* <Stack.Screen name="Home" component={HomeScreen} /> */}
        <Stack.Screen name="Home" component={Start1} />

        {/* <Stack.Screen name="Details" component={DetailsScreen} /> */}
        <Stack.Screen name="Start2" component={Start2} />

        {/* <Stack.Screen name="Screen3" component={Screen3} /> */}

        <Stack.Screen name="Screen3" component={Start3} />

        <Stack.Screen name="HomeScreen" component={HomeScreenMain} />
        <Stack.Screen name="ProfileEdit" component={ProfileEdit} />
        <Stack.Screen name="SubscriptionPlan" component={SubscriptionPlan} />
        <Stack.Screen name="SignIn" component={SignIn} />
        <Stack.Screen name="SignUp" component={SignUp} />
        <Stack.Screen name="HomeFinal" component={Homefinal} />
        <Stack.Screen name="EditProfile" component={EditProfile} />
        <Stack.Screen name="SelectQuiz" component={SelectQuiz} />
        <Stack.Screen name="Quiz" component={Quiz} />
        <Stack.Screen name="MonthlyCompetition" component={MonthlyCompetition} />
        <Stack.Screen name="CameraScreen" component={CameraScreen} />
        <Stack.Screen name="ReTakeScreen" component={ReTakeScreen} />
        <Stack.Screen name="TypeYourQuestion" component={TypeYourQuestion} />
        <Stack.Screen name="About" component={About} />
        <Stack.Screen name="Learning" component={Learning} />
        <Stack.Screen name="SubscriptionPlanUnpaid" component={SubscriptionPlanUnpaid} />
        <Stack.Screen name="FAQ" component={FAQ} />
        <Stack.Screen name="QuestionAndAnswer" component={QuestionAndAnswer} />
        <Stack.Screen name="QuizRightAnswer" component={QuizRightAnswer} />
        <Stack.Screen name="QuizSolve" component={QuizSolve} />
        <Stack.Screen name="Help" component={Help} />
        <Stack.Screen name="BrainPage2" component={BrainPage2} />
        <Stack.Screen name="ParentalReports" component={ParentalReports} />
        <Stack.Screen name="Result" component={Result} />
        <Stack.Screen name="TimeTable" component={TimeTable} />
        <Stack.Screen name="ShowQuiz" component={ShowQuiz} />
        <Stack.Screen name="PaymentMethod" component={PaymentMethod} />
        <Stack.Screen name="Wallet" component={Wallet} />













      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
    width: "100%"
  },

  buttonWrapper: {
    width: 310,
    borderRadius: 20,
    marginBottom: 16,
    top: "-19%",
  },

  buttonContainer: {
    flex: 1,
    backgroundColor: '#FF5733', // Change button color
    borderRadius: 20, // Adjust border radius
  },


  image: {
    width: "80%",
    height: 300,
    top: "18%"

  },

  image1: {

    top: "19%"

  },

  image2: {
    width: "90%",
    height: 300,
    top: "17%"

  },

  image21: {
    top: "12.5%",
    marginLeft: 90


  },

  image3: {
    width: "80%",
    height: 300,
    top: "22%"

  },

  image31: {
    top: "17%",
    width: 250
  },



});




export default App;
